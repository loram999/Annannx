#!/usr/bin/env python3
"""Generate mock draw data for King Lottery — wingo + wintrx, 500 each."""
import json, os, time

def gen_wingo_history(count=500):
    """Generate past WinGo draws ending just before now."""
    EPOCH = 1700000000000
    INTERVAL = 60_000
    now = int(time.time() * 1000)
    seq_now = (now - EPOCH) // INTERVAL + 1
    seq_start = max(1, seq_now - count)
    draws = []
    for seq in range(seq_start, seq_now):
        period_start = EPOCH + (seq - 1) * INTERVAL
        yyyymmdd = time.strftime("%Y%m%d", time.gmtime(period_start / 1000))
        period_id = f"{yyyymmdd}-{seq:04d}"
        seed = sum(ord(c) * (i + 1) for i, c in enumerate(period_id)) & 0xFFFFFFFF
        a = seed
        a = (a + 0x6D2B79F5) & 0xFFFFFFFF
        t = a
        t = ((t ^ (t >> 15)) * (t | 1)) & 0xFFFFFFFF
        t = (t ^ (t + ((t ^ (t >> 7)) * (t | 61)) & 0xFFFFFFFF)) & 0xFFFFFFFF
        r = ((t ^ (t >> 14)) & 0xFFFFFFFF) / 4294967296
        num = int(r * 100) % 100

        if num == 0 or num == 5:
            color = "violet"
        elif num % 2 == 0:
            color = "violet" if (num // 2) % 2 == 0 else "red"
        else:
            color = "green"

        size = "big" if num >= 50 else "small"
        parity = "even" if num % 2 == 0 else "odd"

        draws.append({
            "periodId": period_id,
            "num": num,
            "color": color,
            "size": size,
            "parity": parity,
            "ts": period_start,
        })
    return draws

def gen_wintrx_history(count=500):
    """Generate past WinTrx draws."""
    EPOCH = 1700000000000
    INTERVAL = 60_000
    now = int(time.time() * 1000)
    seq_now = (now - EPOCH) // INTERVAL + 1
    seq_start = max(1, seq_now - count)
    draws = []
    for seq in range(seq_start, seq_now):
        period_start = EPOCH + (seq - 1) * INTERVAL
        yyyymmdd = time.strftime("%Y%m%d", time.gmtime(period_start / 1000))
        period_id = f"TRX-{yyyymmdd}-{seq:04d}"
        seed = sum(ord(c) * (i + 1) for i, c in enumerate(period_id)) & 0xFFFFFFFF
        a = seed
        a = (a + 0x6D2B79F5) & 0xFFFFFFFF
        t = a
        t = ((t ^ (t >> 15)) * (t | 1)) & 0xFFFFFFFF
        t = (t ^ (t + ((t ^ (t >> 7)) * (t | 61)) & 0xFFFFFFFF)) & 0xFFFFFFFF
        r = ((t ^ (t >> 14)) & 0xFFFFFFFF) / 4294967296
        num = int(r * 10) % 10
        chain_hash = hex(int(r * (2**32)) & 0xFFFFFFFF)[2:].upper().zfill(8)[:6]
        draws.append({
            "periodId": period_id,
            "num": num,
            "chainHash": chain_hash,
            "ts": period_start,
        })
    return draws

def gen_winners(count=30):
    """Generate today's winners — masked usernames + avatars + prizes."""
    names = [
        "Mg Mg", "Aye Aye", "Kyaw Kyaw", "Su Su", "Tun Tun",
        "Mya Mya", "Aung Aung", "Hla Hla", "Win Win", "Nu Nu",
        "Ko Ko", "Yi Yi", "Bo Bo", "Cho Cho", "Min Min",
        "Thiri", "Zaw Zaw", "Hnin", "Phyo", "Lay",
    ]
    games = ["WinGo 1Min", "WinGo 3Min", "WinGo 5Min", "WinTrx", "Gold Goal", "WinTrx 3Min"]
    prizes = [1200, 3500, 8500, 12500, 22000, 48000, 95000, 125000, 240000, 480000]
    winners = []
    import random
    random.seed(20260806)
    for i in range(count):
        n = random.choice(names)
        masked = (n[:1] if len(n) >= 2 else n) + ("***" + str(random.randint(100, 999)))
        winners.append({
            "id": i + 1,
            "name": masked,
            "avatar": n[:1].upper(),
            "game": random.choice(games),
            "prize": random.choice(prizes) * random.randint(1, 5),
        })
    return winners

def gen_markets():
    return [
        {"id": "wingo",  "label": "WinGo 1Min",  "intervalMs": 60_000,  "category": "lottery", "active": True,  "popular": True},
        {"id": "wingo3", "label": "WinGo 3Min",  "intervalMs": 180_000, "category": "lottery", "active": True,  "popular": False, "soon": True},
        {"id": "wingo5", "label": "WinGo 5Min",  "intervalMs": 300_000, "category": "lottery", "active": True,  "popular": False, "soon": True},
        {"id": "wintrx", "label": "WinTrx 1Min", "intervalMs": 60_000,  "category": "lottery", "active": True,  "popular": True},
        {"id": "gold",   "label": "Gold Goal",   "intervalMs": 0,       "category": "mini",    "active": True,  "popular": True},
        {"id": "dice",   "label": "Dice",        "intervalMs": 0,       "category": "mini",    "active": False, "soon": True},
        {"id": "slots",  "label": "Slots",       "intervalMs": 0,       "category": "mini",    "active": False, "soon": True},
        {"id": "aviator","label": "Aviator",     "intervalMs": 0,       "category": "mini",    "active": False, "soon": True},
    ]

def main():
    out = "/tmp/king-lottery/data"
    os.makedirs(out, exist_ok=True)

    print("Generating WinGo draws...")
    with open(f"{out}/draws-wingo.json", "w") as f:
        json.dump(gen_wingo_history(500), f, separators=(",", ":"))

    print("Generating WinTrx draws...")
    with open(f"{out}/draws-wintrx.json", "w") as f:
        json.dump(gen_wintrx_history(500), f, separators=(",", ":"))

    print("Generating winners...")
    with open(f"{out}/winners.json", "w") as f:
        json.dump(gen_winners(30), f, separators=(",", ":"))

    print("Generating markets...")
    with open(f"{out}/markets.json", "w") as f:
        json.dump(gen_markets(), f, separators=(",", ":"))

    for f in ["draws-wingo.json", "draws-wintrx.json", "winners.json", "markets.json"]:
        size = os.path.getsize(f"{out}/{f}")
        print(f"  {f}: {size} bytes")

if __name__ == "__main__":
    main()