# Deploy King Lottery to your own VPS

> **Target:** Ubuntu 22.04 / Debian 12 (root or `sudo`)
> **Stack:** Node 20, Express, SQLite, systemd, nginx, certbot
> **Result:** Backend running 24/7, frontend served at `https://yourdomain/`,
> WinGo + WinTrx draws synced from `draw.ar-lottery01.com` every minute.

---

## 1. Upload the bundle

```bash
# from your laptop
scp king-lottery-vps.tar.gz root@YOUR_VPS_IP:/root/
```

Or download directly on the VPS from a release URL:

```bash
ssh root@YOUR_VPS_IP
curl -fSL https://github.com/loram999/Annannx/releases/latest/download/king-lottery-vps.tar.gz -o kl.tar.gz
mkdir -p /opt/king-lottery && tar -xzf kl.tar.gz -C /opt/king-lottery --strip-components=1
cd /opt/king-lottery
```

## 2. Run the installer

```bash
sudo bash deploy/install.sh
```

The installer:

1. Installs Node 20, nginx, ufw
2. Creates a `kinglottery` system user
3. Installs `npm` deps in `/opt/king-lottery/server`
4. Generates a **strong random JWT_SECRET** in `server/.env`
5. Drops a systemd unit (`/etc/systemd/system/king-lottery.service`)
6. Drops an nginx site (`/etc/nginx/sites-available/king-lottery.conf`)
7. Starts the backend on `127.0.0.1:4000` and nginx on `:80`

## 3. Edit `server/.env`

```bash
sudo nano /opt/king-lottery/server/.env
```

Required changes:

| Var             | Purpose                                                              |
|-----------------|----------------------------------------------------------------------|
| `JWT_SECRET`    | Long random string (already generated — keep it)                     |
| `ADMIN_PHONE`   | Phone of the user that becomes the first admin (must register first) |
| `CORS_ORIGINS`  | Your domain, e.g. `https://kinglottery.example.com`                   |
| `AR_API_BASE`   | `https://draw.ar-lottery01.com` (default; change if you proxy it)    |
| `SYNC_INTERVAL` | Seconds between sync runs. `60` = every minute                      |
| `BACKFILL_PAGES`| Pages of history to import on first run                              |

Then restart:

```bash
sudo systemctl restart king-lottery
journalctl -u king-lottery -f      # follow logs
```

## 4. Add HTTPS (certbot)

```bash
# Point your domain A record to the VPS first
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d yourdomain.example
```

Certbot will patch `nginx` to redirect HTTP→HTTPS and reload.

## 5. Verify

```bash
curl -fsSL https://yourdomain.example/api/health | jq
```

Expected:

```json
{
  "ok": true,
  "version": "2.0.0",
  "db": { "users": 0, "wingo": 0, "wintrx": 0 },
  "lastSync": null,
  ...
}
```

After a minute, `db.wingo` and `db.wintrx` should be growing.

## 6. Daily operations

```bash
# Status / logs
sudo systemctl status king-lottery
sudo journalctl -u king-lottery -n 100 --no-pager

# Manual sync trigger (admin JWT required)
TOKEN=$(curl -fsSL -X POST https://yourdomain.example/api/auth/login \
   -H 'Content-Type: application/json' \
   -d '{"phone":"09...","password":"..."}' | jq -r .access_token)
curl -fsSL -X POST https://yourdomain.example/api/wingo/sync \
   -H "Authorization: Bearer $TOKEN"

# Backup the SQLite database
sudo cp /opt/king-lottery/server/data/king.db /root/king-$(date +%F).db
# or for online backup (no downtime):
sudo sqlite3 /opt/king-lottery/server/data/king.db ".backup /root/king-$(date +%F).db"

# Restore
sudo systemctl stop king-lottery
sudo cp /root/king-2026-08-07.db /opt/king-lottery/server/data/king.db
sudo systemctl start king-lottery

# Update
cd /opt/king-lottery
sudo -u kinglottery git pull    # if you cloned via git
sudo npm install --omit=dev     # in /opt/king-lottery/server
sudo systemctl restart king-lottery
```

## 7. Trouble-shooting

| Symptom                            | Check                                                              |
|------------------------------------|--------------------------------------------------------------------|
| `JWT_SECRET env var must be set`   | `sudo nano /opt/king-lottery/server/.env` — uncomment & set        |
| `Error: EADDRINUSE :::4000`        | `sudo lsof -i :4000` — kill the stale node process                 |
| Site loads but draws are missing   | `journalctl -u king-lottery -n 200 \| grep -i sync`                |
| CORS errors in browser             | `CORS_ORIGINS` in `.env` must match the origin (incl. https://)    |
| 502 Bad Gateway                    | `sudo systemctl status king-lottery` — backend must be running    |
| Old draws only                     | `MANUAL_MODE=false` + `SYNC_INTERVAL=60` in `.env`                 |

## Files installed

```
/opt/king-lottery/
├── data/                    SQLite db lives here
├── server/
│   ├── .env                 (created on install; not committed)
│   ├── package.json
│   ├── node_modules/
│   └── src/                 Express app
├── css/, js/, png/, ...     static frontend (served by Express + nginx)
└── home/                    game pages
```

```
/etc/systemd/system/king-lottery.service
/etc/nginx/sites-available/king-lottery.conf  → sites-enabled/
```

## Zero-downtime update recipe

```bash
sudo systemctl stop king-lottery
sudo -u kinglottery bash -c 'cd /opt/king-lottery && git pull && cd server && npm install --omit=dev'
sudo systemctl start king-lottery
sudo journalctl -u king-lottery -f
```

The systemd unit has `Restart=on-failure` with a 5s delay — a crash will
auto-recover. Pair with an uptime monitor (UptimeRobot, Better Uptime, etc.)
for alerts.
