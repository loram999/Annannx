# King Lottery v2.0.0 — Self-Hosted VPS Edition

A complete lottery site (WinGo 1-min, WinTrx 1-min, Gold mini-game) that
**you own and host on your own VPS**. Backend runs 24/7, syncs real draws
from `draw.ar-lottery01.com`, saves history to SQLite, and serves the
frontend from the same Node process.

## What's new in 2.0.0

- **Backend moved to your VPS** — no more Vercel auto-disables, no more Cloudflare Workers size limits, no third-party limits on traffic or uptime
- **Real WinGo + WinTrx sync daemon** (`server/src/sync.js`) — pulls from `ar-lottery01.com` every minute, with multi-strategy fallback (custom upstream, fake seed if all blocked)
- **SQLite history with pagination** — `/api/wingo/draws?page=1&limit=50` returns real history. Users can browse pages of past results.
- **Self-contained JWT auth** — `/api/auth/{register,login,refresh,me,logout}`. No Supabase dependency. Passwords bcrypt-hashed, tokens HS256 signed.
- **Wallet + VIP + Promotions API** — full server-side equivalents of the previous Supabase calls
- **Admin endpoints** — manual draw push, deposit/withdraw approval
- **Deployment script** — `deploy/install.sh` does Node + nginx + systemd in one shot
- **Static fallback** — frontend still works offline by reading `/data/draws-*.json` if backend is unreachable

## Architecture

```
┌──────────────┐    HTTPS    ┌──────────────────────────────────────┐
│   Browser    │ ─────────►  │  nginx (80/443)                       │
│  (frontend)  │             │   └─ /api/* and / → Express :4000    │
└──────────────┘             │      ├─ /api/wingo/*  paginated       │
                             │      ├─ /api/wintrx/* paginated       │
                             │      ├─ /api/auth/*   JWT             │
                             │      ├─ /api/wallet/* + /vip + ...    │
                             │      └─ static  css/, js/, png/, home/│
                             │                                       │
                             │   SQLite ◄── sync daemon (node-cron)  │
                             │     ▲                                │
                             │     └─── https://draw.ar-lottery01.com│
                             └──────��───────────────────────────────���
```

## Quick start (VPS)

```bash
# 1. Upload + extract
scp king-lottery-vps.tar.gz root@YOUR_VPS:/root/
ssh root@YOUR_VPS
mkdir -p /opt/king-lottery && tar -xzf king-lottery-vps.tar.gz -C /opt/king-lottery --strip-components=1
cd /opt/king-lottery

# 2. Install (Node 20, nginx, systemd unit, .env)
sudo bash deploy/install.sh

# 3. Edit secrets
sudo nano /opt/king-lottery/server/.env    # set ADMIN_PHONE, CORS_ORIGINS, JWT_SECRET

# 4. HTTPS
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d yourdomain.example

# 5. Verify
curl -fsSL https://yourdomain.example/api/health | jq
```

Full operations guide in [`deploy/README.md`](deploy/README.md).

## Local development

```bash
# Backend
cd server
cp .env.example .env       # then set JWT_SECRET=any-long-string
npm install
npm run dev                # starts Express + sync daemon

# Frontend (separate terminal)
cd ..
python3 -m http.server 8080
open http://localhost:8080
```

The frontend auto-detects when `/api/*` is reachable. If you load the page from
`:8080` and the backend is on `:4000`, prepend this **before** `js/config.js`
loads:

```html
<script>window.CONFIG = { API_BASE: 'http://localhost:4000/api' };</script>
```

## Project layout

```
.
├── index.html               Home page (hero, ticker, game cards, winners)
├── 404.html
├── css/                     Tokens, base, layout, components, pages
├── js/
│   ├── api.js               Frontend API client (auth, wallet, wingo, wintrx, …)
│   ├── config.js            API_BASE override hook + branding + VIP levels
│   ├── draw-engine.js       Period ID generator + countdown (mock fallback)
│   ├── i18n.js              Burmese + English translation table
│   └── …
├── data/
│   ├── draws-wingo.json     Bundled fallback (used when VPS is offline)
│   ├── draws-wintrx.json
│   └── …
├── home/
│   ├── alllotterygames/
│   │   ├── wingo/           Live game page (uses /api/wingo/draws)
│   │   └── wintrx/          Live game page (uses /api/wintrx/draws)
│   └── minigame/gold/       Mines-style reveal game (local mock only)
├── png/                     SVG icons (logo, games, payments)
├── server/                  ★ VPS backend
│   ├── package.json
│   ├── .env.example
│   └── src/
│       ├── server.js        Express boot + static + sync start
│       ├── db.js            better-sqlite3 schema + WAL + FK
│       ├── sync.js          node-cron periodic sync
│       ├── lib/
│       │   ├── auth.js      JWT sign/verify + middleware
│       │   ├── draw.js      colorFor/sizeFor/parityFor
│       │   └── sources.js   ar-lottery01 + custom upstream + fake fallback
│       └── routes/
│           ├── auth.js      /api/auth/{register,login,refresh,me,logout}
│           ├── wingo.js     /api/wingo/{draws,latest,period,stats,sync}
│           ├── wintrx.js    /api/wintrx/{draws,latest,period,stats,sync}
│           └── profile.js   /api/{profile,wallet/*,vip,promotions,winners,admin/*}
└── deploy/                  ★ VPS installer
    ├── install.sh           One-shot Node + nginx + systemd
    ├── king-lottery.service systemd unit (also installed by install.sh)
    ├── nginx.conf           Reverse proxy template
    └── README.md            Day-2 ops guide (backup, update, troubleshoot)
```

## API surface

All under `/api`:

```
GET    /health                              Stats + config
POST   /auth/register                       { phone, password, nickname?, inviteCode? }
POST   /auth/login                          { phone, password }
POST   /auth/refresh                        { refresh_token }
GET    /auth/me                             (auth)
POST   /auth/logout                         (auth)

GET    /profile                             (auth)
PATCH  /profile                             { nickname?, country?, avatar_url? }

GET    /wingo/draws?page=1&limit=50         Paginated history
GET    /wingo/latest?count=10
GET    /wingo/period/:id
GET    /wingo/stats
POST   /wingo/sync                          (admin)

GET    /wintrx/draws?page=1&limit=50        Paginated history
GET    /wintrx/latest?count=10
GET    /wintrx/period/:id
GET    /wintrx/stats
POST   /wintrx/sync                         (admin)

GET    /wallet/gateways
POST   /wallet/deposit                      (auth) { gateway, amount, accountName, accountNumber, screenshot? }
POST   /wallet/withdraw                     (auth) { bankId, accountNumber, accountName, amount, password }
GET    /wallet/history?type=deposits|withdraws (auth)

GET    /winners?date=YYYY-MM-DD
GET    /promotions
GET    /vip                                 (auth)

POST   /admin/deposits/:id/approve          (admin)
POST   /admin/withdraws/:id/approve         (admin)
POST   /admin/withdraws/:id/reject          (admin)
POST   /admin/draws                         (admin) { market: 'wingo'|'wintrx', draw: { … } }
```

All auth endpoints accept/return tokens shaped like Supabase so the existing
frontend session code (`localStorage.king.api.access_token`) works unchanged:

```json
{
  "access_token":  "eyJ…",
  "refresh_token": "eyJ…",
  "token":         "eyJ…",
  "user": { "id": 1, "phone": "09…", "is_admin": 0, "balance": 0, … }
}
```

## Draw sources

Primary: `https://draw.ar-lottery01.com/WinGo/WinGo_1M/GetHistoryIssuePage.json`
Mirror: `https://draw.ar-lottery01.com/TrxWinGo/TrxWinGo_1M/GetHistoryIssuePage.json`

Both proxied through the VPS — your visitors never see the upstream directly.
If the upstream is blocked (Cloudflare bot challenge), `lib/sources.js` falls
through to:

1. `SOURCE_BASE_URL` + `SOURCE_TOKEN` (your own proxy / VPS)
2. Seeded fake draws (mulberry32 RNG, deterministic per period ID)

To force manual entry only (no outbound fetch at all):

```env
MANUAL_MODE=true
```

Then POST to `/api/admin/draws` with each new result.

## License

Provided as-is for self-hosted deployment. No warranty.

## Credits

- Frontend design: Burmese-locale UI originally inspired by `Annannx` repo, fully rewritten from scratch
- Upstream draws: `ar-lottery01.com`
- Real-time backend: built on Express, better-sqlite3, node-cron
