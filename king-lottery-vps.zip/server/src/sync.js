/* ============================================================
   Sync daemon — fetches latest draws from ar-lottery01.com (or
   fallback source) on a cron, stores in SQLite.
   ============================================================ */

import cron from 'node-cron';
import db from './db.js';
import { fetchDraws } from './lib/sources.js';
import { normalizeWingo, normalizeWintrx } from './lib/draw.js';

const insertWingo = db.prepare(`
  INSERT OR IGNORE INTO wingo_draws (period_id, num, color, size, parity, ts, raw)
  VALUES (@periodId, @num, @color, @size, @parity, @ts, @raw)
`);

const insertWintrx = db.prepare(`
  INSERT OR IGNORE INTO wintrx_draws (period_id, num, color, parity, ts, raw)
  VALUES (@periodId, @num, @color, @parity, @ts, @raw)
`);

const logSync = db.prepare(`
  INSERT INTO sync_log (source, status, rows, error) VALUES (?, ?, ?, ?)
`);

async function syncMarket(market, page = 1) {
  const label = market === 'wintrx' ? 'WinTrx' : 'WinGo';
  try {
    const { rows, source } = await fetchDraws(market, page);
    let inserted = 0;
    const insert = market === 'wintrx' ? insertWintrx : insertWingo;
    const normalize = market === 'wintrx' ? normalizeWintrx : normalizeWingo;
    for (const r of rows) {
      const n = normalize(r);
      if (!n) continue;
      const result = insert.run(n);
      if (result.changes > 0) inserted++;
    }
    logSync.run(`${label}:${source}`, 'ok', inserted, null);
    console.log(`[sync] ${label} page ${page}: fetched ${rows.length}, inserted ${inserted}`);
    return inserted;
  } catch (e) {
    logSync.run(`${label}:page${page}`, 'error', 0, e.message);
    console.error(`[sync] ${label} page ${page}: ${e.message}`);
    return 0;
  }
}

async function syncLatest() {
  await Promise.all([
    syncMarket('wingo'),
    syncMarket('wintrx'),
  ]);
}

async function backfill(market, pages) {
  console.log(`[sync] Backfilling ${market}: ${pages} pages...`);
  for (let p = 1; p <= pages; p++) {
    await syncMarket(market, p);
    // small delay to be polite
    await new Promise(r => setTimeout(r, 500));
  }
}

export { syncMarket };

export function startSync() {
  if (process.env.MANUAL_MODE === 'true') {
    console.log('[sync] MANUAL_MODE — sync daemon disabled. Use POST /api/admin/draws to push draws manually.');
    return;
  }

  const interval = parseInt(process.env.SYNC_INTERVAL || '60', 10);
  const backfillPages = parseInt(process.env.BACKFILL_PAGES || '10', 10);

  // Run once on boot
  console.log(`[sync] Starting sync daemon (every ${interval}s, backfill ${backfillPages} pages)`);
  syncLatest().catch(e => console.error('[sync] initial:', e.message));

  // Backfill on boot (separate from latest sync)
  if (backfillPages > 0) {
    setTimeout(() => {
      backfill('wingo', backfillPages).catch(e => console.error('[sync] backfill wingo:', e.message));
      backfill('wintrx', backfillPages).catch(e => console.error('[sync] backfill wintrx:', e.message));
    }, 5000);
  }

  // Schedule periodic sync
  // Cron expression: every N seconds isn't supported by cron, so use seconds-aware math
  const cronExpr = interval < 60
    ? `*/${interval} * * * * *`  // every N seconds (6-field cron)
    : `*/${Math.floor(interval / 60)} * * * *`;  // every N minutes

  try {
    cron.schedule(cronExpr, () => {
      syncLatest().catch(e => console.error('[sync] tick:', e.message));
    });
    console.log(`[sync] Scheduled: "${cronExpr}"`);
  } catch (e) {
    console.error(`[sync] Failed to schedule cron "${cronExpr}": ${e.message}`);
    // Fallback: setInterval
    setInterval(() => {
      syncLatest().catch(e => console.error('[sync] tick:', e.message));
    }, interval * 1000);
  }
}

// Allow running sync standalone: `node src/sync.js`
if (import.meta.url === `file://${process.argv[1]}`) {
  console.log('[sync] Standalone run');
  await syncLatest();
  process.exit(0);
}
