/* ============================================================
   /api/wintrx/*  — paginated WinTrx draws
   ============================================================ */

import { Router } from 'express';
import db from '../db.js';
import { syncMarket } from '../sync.js';

const router = Router();

router.get('/draws', (req, res) => {
  const page = Math.max(1, parseInt(req.query.page || '1', 10));
  const limit = Math.min(200, Math.max(1, parseInt(req.query.limit || '50', 10)));
  const offset = (page - 1) * limit;

  const rows = db.prepare(`
    SELECT period_id, num, color, parity, ts
    FROM wintrx_draws
    ORDER BY ts DESC, id DESC
    LIMIT ? OFFSET ?
  `).all(limit, offset);

  const total = db.prepare('SELECT COUNT(*) as c FROM wintrx_draws').get().c;
  const totalPages = Math.ceil(total / limit);

  res.json({
    page,
    limit,
    total,
    totalPages,
    hasNext: page < totalPages,
    hasPrev: page > 1,
    draws: rows.map(r => ({
      periodId: r.period_id,
      num: r.num,
      color: r.color,
      parity: r.parity,
      ts: r.ts,
    })),
  });
});

router.get('/latest', (req, res) => {
  const count = Math.min(50, Math.max(1, parseInt(req.query.count || '10', 10)));
  const rows = db.prepare(`
    SELECT period_id, num, color, parity, ts
    FROM wintrx_draws
    ORDER BY ts DESC, id DESC
    LIMIT ?
  `).all(count);
  res.json({
    draws: rows.map(r => ({
      periodId: r.period_id,
      num: r.num,
      color: r.color,
      parity: r.parity,
      ts: r.ts,
    })),
  });
});

router.get('/period/:id', (req, res) => {
  const row = db.prepare('SELECT * FROM wintrx_draws WHERE period_id = ?').get(req.params.id);
  if (!row) return res.status(404).json({ error: 'Period not found' });
  res.json({
    draw: {
      periodId: row.period_id,
      num: row.num,
      color: row.color,
      parity: row.parity,
      ts: row.ts,
    },
  });
});

router.get('/stats', (req, res) => {
  const total = db.prepare('SELECT COUNT(*) as c FROM wintrx_draws').get().c;
  const last = db.prepare('SELECT ts FROM wintrx_draws ORDER BY ts DESC LIMIT 1').get();
  const lastSync = db.prepare(`
    SELECT ts FROM sync_log WHERE source LIKE 'WinTrx:%' ORDER BY id DESC LIMIT 1
  `).get();
  res.json({ total, lastDrawTs: last?.ts || null, lastSyncTs: lastSync?.ts || null });
});

router.post('/sync', async (req, res) => {
  const page = parseInt(req.query.page || req.body?.page || '1', 10);
  const inserted = await syncMarket('wintrx', page);
  res.json({ ok: true, inserted });
});

export default router;
