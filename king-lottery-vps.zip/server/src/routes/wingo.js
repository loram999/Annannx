/* ============================================================
   /api/wingo/*  — paginated WinGo draws (real-time from ar-lottery01)
   ============================================================ */

import { Router } from 'express';
import db from '../db.js';
import { syncMarket } from '../sync.js';

const router = Router();

/**
 * GET /api/wingo/draws?page=1&limit=50
 * Paginated history. Pages are 1-indexed.
 */
router.get('/draws', (req, res) => {
  const page = Math.max(1, parseInt(req.query.page || '1', 10));
  const limit = Math.min(200, Math.max(1, parseInt(req.query.limit || '50', 10)));
  const offset = (page - 1) * limit;

  const rows = db.prepare(`
    SELECT period_id, num, color, size, parity, ts
    FROM wingo_draws
    ORDER BY ts DESC, id DESC
    LIMIT ? OFFSET ?
  `).all(limit, offset);

  const total = db.prepare('SELECT COUNT(*) as c FROM wingo_draws').get().c;
  const totalPages = Math.ceil(total / limit);

  res.json({
    page,
    limit,
    total,
    totalPages,
    hasNext: page < totalPages,
    hasPrev: page > 1,
    draws: rows.map(r => ({
      periodId: r.period_id,
      num: r.num,
      color: r.color,
      size: r.size,
      parity: r.parity,
      ts: r.ts,
    })),
  });
});

/** GET /api/wingo/latest?count=10 — most recent draws (for ticker) */
router.get('/latest', (req, res) => {
  const count = Math.min(50, Math.max(1, parseInt(req.query.count || '10', 10)));
  const rows = db.prepare(`
    SELECT period_id, num, color, size, parity, ts
    FROM wingo_draws
    ORDER BY ts DESC, id DESC
    LIMIT ?
  `).all(count);
  res.json({
    draws: rows.map(r => ({
      periodId: r.period_id,
      num: r.num,
      color: r.color,
      size: r.size,
      parity: r.parity,
      ts: r.ts,
    })),
  });
});

/** GET /api/wingo/period/:id — single draw */
router.get('/period/:id', (req, res) => {
  const row = db.prepare('SELECT * FROM wingo_draws WHERE period_id = ?').get(req.params.id);
  if (!row) return res.status(404).json({ error: 'Period not found' });
  res.json({
    draw: {
      periodId: row.period_id,
      num: row.num,
      color: row.color,
      size: row.size,
      parity: row.parity,
      ts: row.ts,
    },
  });
});

/** GET /api/wingo/stats — count + last sync */
router.get('/stats', (req, res) => {
  const total = db.prepare('SELECT COUNT(*) as c FROM wingo_draws').get().c;
  const last = db.prepare('SELECT ts FROM wingo_draws ORDER BY ts DESC LIMIT 1').get();
  const lastSync = db.prepare(`
    SELECT ts FROM sync_log WHERE source LIKE 'WinGo:%' ORDER BY id DESC LIMIT 1
  `).get();
  res.json({ total, lastDrawTs: last?.ts || null, lastSyncTs: lastSync?.ts || null });
});

/** POST /api/admin/wingo/sync — admin/manual sync trigger */
router.post('/sync', async (req, res) => {
  const page = parseInt(req.query.page || req.body?.page || '1', 10);
  const inserted = await syncMarket('wingo', page);
  res.json({ ok: true, inserted });
});

export default router;
