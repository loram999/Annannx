/* ============================================================
   /api/auth/*  — register, login, me, logout, refresh
   ============================================================ */

import { Router } from 'express';
import bcrypt from 'bcryptjs';
import db from '../db.js';
import { signToken, requireAuth } from '../lib/auth.js';

const router = Router();

// Build the wire-shape the frontend expects (Supabase-style for backwards-compat)
function tokensFor(user) {
  const access = signToken(user, '7d');
  const refresh = signToken({ id: user.id }, '30d', { typ: 'refresh' });
  return { access_token: access, refresh_token: refresh };
}

router.post('/register', async (req, res) => {
  const { phone, password, nickname, country, inviteCode } = req.body || {};
  if (!phone || !password) return res.status(400).json({ error: 'phone and password required' });
  if (password.length < 6) return res.status(400).json({ error: 'password must be at least 6 chars' });

  const expectedInvite = process.env.REGISTER_SECRET;
  if (expectedInvite && inviteCode !== expectedInvite) {
    return res.status(403).json({ error: 'Invalid invite code' });
  }

  const exists = db.prepare('SELECT id FROM users WHERE phone = ?').get(phone);
  if (exists) return res.status(409).json({ error: 'Phone already registered' });

  const hash = await bcrypt.hash(password, 10);
  const isFirst = db.prepare('SELECT COUNT(*) as c FROM users').get().c === 0;
  const isAdmin = isFirst && process.env.ADMIN_PHONE && phone === process.env.ADMIN_PHONE ? 1 : 0;

  const result = db.prepare(`
    INSERT INTO users (phone, password_hash, nickname, country, is_admin)
    VALUES (?, ?, ?, ?, ?)
  `).run(phone, hash, nickname || null, country || 'MM', isAdmin);

  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(result.lastInsertRowid);
  const tokens = tokensFor(user);

  res.json({ ...tokens, token: tokens.access_token, user: sanitize(user) });
});

router.post('/login', async (req, res) => {
  const { phone, password } = req.body || {};
  if (!phone || !password) return res.status(400).json({ error: 'phone and password required' });

  const user = db.prepare('SELECT * FROM users WHERE phone = ?').get(phone);
  if (!user) return res.status(401).json({ error: 'Invalid phone or password' });
  if (user.is_blocked) return res.status(403).json({ error: 'Account blocked' });

  const ok = await bcrypt.compare(password, user.password_hash);
  if (!ok) return res.status(401).json({ error: 'Invalid phone or password' });

  const tokens = tokensFor(user);
  res.json({ ...tokens, token: tokens.access_token, user: sanitize(user) });
});

router.post('/refresh', (req, res) => {
  const { refresh_token } = req.body || {};
  if (!refresh_token) return res.status(400).json({ error: 'refresh_token required' });

  let payload;
  try {
    payload = require('../lib/auth.js').verifyToken(refresh_token);
  } catch (e) {
    return res.status(401).json({ error: 'invalid refresh token' });
  }
  if (payload?.typ !== 'refresh') return res.status(401).json({ error: 'not a refresh token' });

  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(payload.id);
  if (!user || user.is_blocked) return res.status(401).json({ error: 'user not found or blocked' });

  const tokens = tokensFor(user);
  res.json({ ...tokens, token: tokens.access_token, user: sanitize(user) });
});

router.get('/me', requireAuth, (req, res) => {
  res.json({ user: sanitize(req.user) });
});

router.post('/logout', (req, res) => {
  // JWT is stateless — client just deletes the token
  res.json({ ok: true });
});

function sanitize(u) {
  const { password_hash, ...rest } = u;
  return rest;
}

export default router;
