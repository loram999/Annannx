/* ============================================================
   /api/profile, /api/wallet/*, /api/winners, /api/promotions, /api/vip
   ============================================================ */

import { Router } from 'express';
import db from '../db.js';
import { requireAuth } from '../lib/auth.js';

const router = Router();

// ── Profile ──
router.get('/profile', requireAuth, (req, res) => {
  const { password_hash, ...profile } = req.user;
  res.json({ profile });
});

router.patch('/profile', requireAuth, (req, res) => {
  const { nickname, country, avatar_url } = req.body || {};
  const patch = {};
  if (nickname !== undefined) patch.nickname = nickname;
  if (country !== undefined) patch.country = country;
  if (avatar_url !== undefined) patch.avatar_url = avatar_url;
  if (Object.keys(patch).length === 0) return res.status(400).json({ error: 'no fields to update' });

  const setClause = Object.keys(patch).map(k => `${k} = @${k}`).join(', ');
  db.prepare(`UPDATE users SET ${setClause}, updated_at = datetime('now') WHERE id = @id`).run({ ...patch, id: req.user.id });

  const updated = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
  const { password_hash, ...profile } = updated;
  res.json({ profile });
});

// ── Wallet: deposit/withdraw/history ──
router.post('/wallet/deposit', requireAuth, (req, res) => {
  const { gateway, amount, accountName, accountNumber, screenshot } = req.body || {};
  if (!gateway || !amount || !accountName || !accountNumber) {
    return res.status(400).json({ error: 'gateway, amount, accountName, accountNumber required' });
  }
  const amt = Number(amount);
  if (!Number.isFinite(amt) || amt <= 0) return res.status(400).json({ error: 'invalid amount' });

  const gw = db.prepare('SELECT * FROM gateways WHERE id = ? AND active = 1').get(gateway);
  if (!gw) return res.status(400).json({ error: 'gateway not available' });
  if (amt < gw.min || amt > gw.max) return res.status(400).json({ error: `amount must be between ${gw.min} and ${gw.max}` });

  const result = db.prepare(`
    INSERT INTO deposits (user_id, gateway, amount, account_name, account_number, screenshot_url)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(req.user.id, gateway, amt, accountName, accountNumber, screenshot || null);

  const dep = db.prepare('SELECT * FROM deposits WHERE id = ?').get(result.lastInsertRowid);
  res.json({ deposit: dep });
});

router.post('/wallet/withdraw', requireAuth, (req, res) => {
  const { bankId, accountNumber, accountName, amount, password } = req.body || {};
  if (!bankId || !accountNumber || !accountName || !amount || !password) {
    return res.status(400).json({ error: 'all fields required' });
  }
  const amt = Number(amount);
  if (!Number.isFinite(amt) || amt <= 0) return res.status(400).json({ error: 'invalid amount' });
  if (req.user.balance < amt) return res.status(400).json({ error: 'insufficient balance' });

  const result = db.prepare(`
    INSERT INTO withdraws (user_id, bank_id, account_number, account_name, amount)
    VALUES (?, ?, ?, ?, ?)
  `).run(req.user.id, bankId, accountNumber, accountName, amt);

  // Deduct balance optimistically (admin can refund if rejected)
  db.prepare(`UPDATE users SET balance = balance - ?, updated_at = datetime('now') WHERE id = ?`)
    .run(amt, req.user.id);

  const wd = db.prepare('SELECT * FROM withdraws WHERE id = ?').get(result.lastInsertRowid);
  res.json({ withdraw: wd });
});

router.get('/wallet/history', requireAuth, (req, res) => {
  const type = (req.query.type || 'deposits').toString();
  if (type === 'deposits') {
    const rows = db.prepare('SELECT * FROM deposits WHERE user_id = ? ORDER BY created_at DESC LIMIT 50').all(req.user.id);
    return res.json({ deposits: rows });
  }
  if (type === 'withdraws') {
    const rows = db.prepare('SELECT * FROM withdraws WHERE user_id = ? ORDER BY created_at DESC LIMIT 50').all(req.user.id);
    return res.json({ withdraws: rows });
  }
  res.status(400).json({ error: 'type must be deposits or withdraws' });
});

router.get('/wallet/gateways', (req, res) => {
  const rows = db.prepare('SELECT * FROM gateways WHERE active = 1 ORDER BY sort_order ASC').all();
  res.json({ gateways: rows });
});

// ── Winners / Promotions / VIP ──
router.get('/winners', (req, res) => {
  const date = (req.query.date || new Date().toISOString().slice(0, 10)).toString();
  const rows = db.prepare(`
    SELECT name, prize, currency, period_id, market, avatar_url
    FROM winners WHERE date = ? ORDER BY prize DESC LIMIT 30
  `).all(date);
  res.json({ date, winners: rows });
});

router.get('/promotions', (req, res) => {
  const rows = db.prepare('SELECT * FROM promotions WHERE active = 1 ORDER BY sort_order ASC').all();
  res.json({ promotions: rows });
});

const LEVELS = [
  { tier: 'bronze',   name: 'Bronze',   minWagered: 0,        rebate: 0.005 },
  { tier: 'silver',   name: 'Silver',   minWagered: 100000,   rebate: 0.007 },
  { tier: 'gold',     name: 'Gold',     minWagered: 500000,   rebate: 0.010 },
  { tier: 'platinum', name: 'Platinum', minWagered: 2000000,  rebate: 0.012 },
  { tier: 'diamond',  name: 'Diamond',  minWagered: 10000000, rebate: 0.015 },
  { tier: 'king',     name: 'King',     minWagered: 50000000, rebate: 0.020 },
];

function computeTier(totalWagered) {
  let current = LEVELS[0];
  for (const lvl of LEVELS) if (totalWagered >= lvl.minWagered) current = lvl;
  const next = LEVELS[LEVELS.indexOf(current) + 1] || null;
  const progress = next
    ? Math.min(1, (totalWagered - current.minWagered) / (next.minWagered - current.minWagered))
    : 1;
  return { current, next, progress };
}

router.get('/vip', requireAuth, (req, res) => {
  const wagered = req.user.total_wagered || 0;
  const tier = computeTier(wagered);
  res.json({
    tier: tier.current,
    next_tier: tier.next,
    progress: tier.progress,
    total_wagered: wagered,
    balance: req.user.balance,
    levels: LEVELS,
  });
});

// ── Admin: deposit/withdraw approval ──
router.post('/admin/deposits/:id/approve', requireAuth, (req, res) => {
  if (!req.user.is_admin) return res.status(403).json({ error: 'admin only' });
  const dep = db.prepare('SELECT * FROM deposits WHERE id = ?').get(req.params.id);
  if (!dep) return res.status(404).json({ error: 'not found' });
  if (dep.status !== 'pending') return res.status(400).json({ error: 'already processed' });

  db.prepare(`UPDATE deposits SET status = 'approved', updated_at = datetime('now') WHERE id = ?`).run(dep.id);
  db.prepare(`UPDATE users SET balance = balance + ? WHERE id = ?`).run(dep.amount, dep.user_id);
  res.json({ ok: true });
});

router.post('/admin/withdraws/:id/approve', requireAuth, (req, res) => {
  if (!req.user.is_admin) return res.status(403).json({ error: 'admin only' });
  const wd = db.prepare('SELECT * FROM withdraws WHERE id = ?').get(req.params.id);
  if (!wd) return res.status(404).json({ error: 'not found' });
  if (wd.status !== 'pending') return res.status(400).json({ error: 'already processed' });

  db.prepare(`UPDATE withdraws SET status = 'approved', updated_at = datetime('now') WHERE id = ?`).run(wd.id);
  res.json({ ok: true });
});

router.post('/admin/withdraws/:id/reject', requireAuth, (req, res) => {
  if (!req.user.is_admin) return res.status(403).json({ error: 'admin only' });
  const wd = db.prepare('SELECT * FROM withdraws WHERE id = ?').get(req.params.id);
  if (!wd) return res.status(404).json({ error: 'not found' });
  if (wd.status !== 'pending') return res.status(400).json({ error: 'already processed' });

  db.prepare(`UPDATE withdraws SET status = 'rejected', updated_at = datetime('now') WHERE id = ?`).run(wd.id);
  // Refund the deducted balance
  db.prepare(`UPDATE users SET balance = balance + ? WHERE id = ?`).run(wd.amount, wd.user_id);
  res.json({ ok: true });
});

// ── Admin: manually push a draw (when source is blocked) ──
router.post('/admin/draws', requireAuth, (req, res) => {
  if (!req.user.is_admin) return res.status(403).json({ error: 'admin only' });
  const { market, draw } = req.body || {};
  if (!market || !draw) return res.status(400).json({ error: 'market and draw required' });

  if (market === 'wingo') {
    db.prepare(`
      INSERT OR IGNORE INTO wingo_draws (period_id, num, color, size, parity, ts, raw)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(draw.periodId, draw.num, draw.color, draw.size, draw.parity, draw.ts || Date.now(), JSON.stringify(draw));
  } else if (market === 'wintrx') {
    db.prepare(`
      INSERT OR IGNORE INTO wintrx_draws (period_id, num, color, parity, ts, raw)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(draw.periodId, draw.num, draw.color, draw.parity, draw.ts || Date.now(), JSON.stringify(draw));
  } else {
    return res.status(400).json({ error: 'market must be wingo or wintrx' });
  }

  res.json({ ok: true });
});

export default router;
