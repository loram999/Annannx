/* ============================================================
   King Lottery — VPS Backend
   Express + SQLite + sync daemon + JWT auth
   ============================================================ */

import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import morgan from 'morgan';
import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import db from './db.js';
import { startSync } from './sync.js';
import authRoutes from './routes/auth.js';
import wingoRoutes from './routes/wingo.js';
import wintrxRoutes from './routes/wintrx.js';
import miscRoutes from './routes/profile.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = parseInt(process.env.PORT || '4000', 10);
const HOST = process.env.HOST || '0.0.0.0';
const FRONTEND_DIR = path.join(__dirname, '..', '..');  // serves the static site

const app = express();
app.set('trust proxy', 1);

// ── Middleware ──
const allowedOrigins = (process.env.CORS_ORIGINS || '*').split(',').map(s => s.trim());
app.use(cors({
  origin: allowedOrigins.includes('*') ? true : allowedOrigins,
  credentials: true,
}));
app.use(express.json({ limit: '1mb' }));
app.use(morgan('tiny'));

// ── API routes ──
app.get('/api/health', (req, res) => {
  const totalUsers = db.prepare('SELECT COUNT(*) as c FROM users').get().c;
  const totalWingo = db.prepare('SELECT COUNT(*) as c FROM wingo_draws').get().c;
  const totalWintrx = db.prepare('SELECT COUNT(*) as c FROM wintrx_draws').get().c;
  const lastSync = db.prepare('SELECT * FROM sync_log ORDER BY id DESC LIMIT 1').get();
  res.json({
    ok: true,
    version: '2.0.0',
    db: { users: totalUsers, wingo: totalWingo, wintrx: totalWintrx },
    lastSync,
    config: {
      manualMode: process.env.MANUAL_MODE === 'true',
      syncInterval: process.env.SYNC_INTERVAL || '60',
      backfillPages: process.env.BACKFILL_PAGES || '10',
    },
    ts: new Date().toISOString(),
  });
});

app.use('/api/auth', authRoutes);
app.use('/api/wingo', wingoRoutes);
app.use('/api/wintrx', wintrxRoutes);
app.use('/api', miscRoutes);

// ── Static frontend ──
app.use(express.static(FRONTEND_DIR, {
  maxAge: '1h',
  setHeaders(res, filepath) {
    if (filepath.match(/\.(css|js|svg|woff2)$/)) {
      res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
    } else if (filepath.match(/\/data\//)) {
      res.setHeader('Cache-Control', 'public, max-age=60');
    }
  },
}));

// ── SPA fallback ──
app.get('*', (req, res) => {
  // For /api/* paths not matched above, return 404 JSON
  if (req.path.startsWith('/api/')) {
    return res.status(404).json({ error: 'Not found', path: req.path });
  }
  res.sendFile(path.join(FRONTEND_DIR, '404.html'));
});

// ── Error handler ──
app.use((err, req, res, next) => {
  console.error('[error]', err);
  res.status(500).json({ error: err.message || 'Internal server error' });
});

// ── Boot ──
const server = http.createServer(app);

server.listen(PORT, HOST, () => {
  console.log(`[server] Listening on http://${HOST}:${PORT}`);
  console.log(`[server] Frontend dir: ${FRONTEND_DIR}`);
  console.log(`[server] DB path: ${db.name}`);
  startSync();
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('[server] SIGTERM — shutting down');
  server.close(() => {
    db.close();
    process.exit(0);
  });
});
process.on('SIGINT', () => {
  console.log('[server] SIGINT — shutting down');
  server.close(() => {
    db.close();
    process.exit(0);
  });
});
