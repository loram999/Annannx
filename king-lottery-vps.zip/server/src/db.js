/* ============================================================
   SQLite schema + helpers
   ============================================================ */

import Database from 'better-sqlite3';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = process.env.DB_PATH || path.join(__dirname, '..', 'data', 'king-lottery.db');

// Ensure the data directory exists before opening the file. This makes
// the backend work from a fresh `tar -xzf` extract without needing
// install.sh to run first.
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

export const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
  -- ── Users ──
  CREATE TABLE IF NOT EXISTS users (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    phone           TEXT UNIQUE NOT NULL,
    password_hash   TEXT NOT NULL,
    nickname        TEXT,
    country         TEXT DEFAULT 'MM',
    balance         REAL DEFAULT 0,
    vip_tier        TEXT DEFAULT 'bronze',
    total_wagered   REAL DEFAULT 0,
    is_admin        INTEGER DEFAULT 0,
    is_blocked      INTEGER DEFAULT 0,
    created_at      TEXT DEFAULT (datetime('now')),
    updated_at      TEXT DEFAULT (datetime('now'))
  );
  CREATE INDEX IF NOT EXISTS idx_users_phone ON users(phone);

  -- ── WinGo draws ──
  CREATE TABLE IF NOT EXISTS wingo_draws (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    period_id       TEXT UNIQUE NOT NULL,
    num             INTEGER NOT NULL,
    color           TEXT NOT NULL,
    size            TEXT NOT NULL,
    parity          TEXT NOT NULL,
    ts              INTEGER NOT NULL,
    raw             TEXT,
    created_at      TEXT DEFAULT (datetime('now'))
  );
  CREATE INDEX IF NOT EXISTS idx_wingo_ts      ON wingo_draws(ts DESC);
  CREATE INDEX IF NOT EXISTS idx_wingo_period  ON wingo_draws(period_id);

  -- ── WinTrx draws ──
  CREATE TABLE IF NOT EXISTS wintrx_draws (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    period_id       TEXT UNIQUE NOT NULL,
    num             INTEGER NOT NULL,
    color           TEXT NOT NULL,
    parity          TEXT NOT NULL,
    ts              INTEGER NOT NULL,
    raw             TEXT,
    created_at      TEXT DEFAULT (datetime('now'))
  );
  CREATE INDEX IF NOT EXISTS idx_wintrx_ts      ON wintrx_draws(ts DESC);
  CREATE INDEX IF NOT EXISTS idx_wintrx_period  ON wintrx_draws(period_id);

  -- ── Winners ──
  CREATE TABLE IF NOT EXISTS winners (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    date            TEXT NOT NULL,
    name            TEXT NOT NULL,
    prize           REAL NOT NULL,
    currency        TEXT DEFAULT 'MMK',
    period_id       TEXT,
    market          TEXT,
    avatar_url      TEXT,
    created_at      TEXT DEFAULT (datetime('now'))
  );
  CREATE INDEX IF NOT EXISTS idx_winners_date ON winners(date DESC);

  -- ── Gateways (payment methods) ──
  CREATE TABLE IF NOT EXISTS gateways (
    id              TEXT PRIMARY KEY,
    name            TEXT NOT NULL,
    icon            TEXT,
    min             REAL DEFAULT 0,
    max             REAL DEFAULT 0,
    account_name    TEXT,
    account_number  TEXT,
    instructions    TEXT,
    active          INTEGER DEFAULT 1,
    sort_order      INTEGER DEFAULT 0
  );

  -- ── Promotions ──
  CREATE TABLE IF NOT EXISTS promotions (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    title           TEXT NOT NULL,
    description     TEXT,
    image_url       TEXT,
    cta_label       TEXT,
    cta_url         TEXT,
    active          INTEGER DEFAULT 1,
    sort_order      INTEGER DEFAULT 0,
    created_at      TEXT DEFAULT (datetime('now'))
  );

  -- ── Deposits ──
  CREATE TABLE IF NOT EXISTS deposits (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id         INTEGER NOT NULL REFERENCES users(id),
    gateway         TEXT,
    amount          REAL NOT NULL,
    account_name    TEXT,
    account_number  TEXT,
    screenshot_url  TEXT,
    status          TEXT DEFAULT 'pending',
    note            TEXT,
    created_at      TEXT DEFAULT (datetime('now')),
    updated_at      TEXT DEFAULT (datetime('now'))
  );
  CREATE INDEX IF NOT EXISTS idx_deposits_user ON deposits(user_id, created_at DESC);

  -- ── Withdraws ──
  CREATE TABLE IF NOT EXISTS withdraws (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id         INTEGER NOT NULL REFERENCES users(id),
    bank_id         TEXT,
    account_number  TEXT,
    account_name    TEXT,
    amount          REAL NOT NULL,
    status          TEXT DEFAULT 'pending',
    note            TEXT,
    created_at      TEXT DEFAULT (datetime('now')),
    updated_at      TEXT DEFAULT (datetime('now'))
  );
  CREATE INDEX IF NOT EXISTS idx_withdraws_user ON withdraws(user_id, created_at DESC);

  -- ── Bets ──
  CREATE TABLE IF NOT EXISTS bets (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id         INTEGER NOT NULL REFERENCES users(id),
    market          TEXT NOT NULL,
    period_id       TEXT NOT NULL,
    type            TEXT NOT NULL,
    selection       TEXT NOT NULL,
    amount          REAL NOT NULL,
    multiplier      REAL DEFAULT 1,
    payout          REAL DEFAULT 0,
    status          TEXT DEFAULT 'pending',
    settled_at      TEXT,
    created_at      TEXT DEFAULT (datetime('now'))
  );
  CREATE INDEX IF NOT EXISTS idx_bets_user ON bets(user_id, created_at DESC);
  CREATE INDEX IF NOT EXISTS idx_bets_period ON bets(market, period_id);

  -- ── Sync log (for debugging) ──
  CREATE TABLE IF NOT EXISTS sync_log (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    source          TEXT NOT NULL,
    status          TEXT NOT NULL,
    rows            INTEGER DEFAULT 0,
    error           TEXT,
    ts              TEXT DEFAULT (datetime('now'))
  );
`);

// ── Seed defaults on first run ──
function seedDefaults() {
  const gwCount = db.prepare('SELECT COUNT(*) as c FROM gateways').get().c;
  if (gwCount === 0) {
    const insert = db.prepare(`
      INSERT INTO gateways (id, name, icon, min, max, account_name, account_number, instructions, active, sort_order)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?)
    `);
    insert.run('kbz',  'KBZ Pay',    '/png/payment-kbz.svg',   1000,  1000000, '', '', 'Send to KBZ Pay account number above, then submit form.', 1);
    insert.run('wave', 'Wave Money', '/png/payment-wave.svg',  1000,  500000,  '', '', 'Send to Wave Money account number above, then submit form.', 2);
    insert.run('aya',  'AYA Pay',    '/png/payment-aya.svg',   5000,  2000000, '', '', 'Send to AYA Pay account number above, then submit form.', 3);
    insert.run('omt',  'OMT',        '/png/payment-omt.svg',   1000,  300000,  '', '', 'Send to OMT account number above, then submit form.', 4);
    insert.run('usdt', 'USDT-TRC20', '/png/payment-usdt.svg',  10000, 5000000, '', '', 'Send USDT-TRC20 to the address above, then submit form with tx hash.', 5);
  }

  const promoCount = db.prepare('SELECT COUNT(*) as c FROM promotions').get().c;
  if (promoCount === 0) {
    const insert = db.prepare(`
      INSERT INTO promotions (title, description, image_url, cta_label, cta_url, active, sort_order)
      VALUES (?, ?, ?, ?, ?, 1, ?)
    `);
    insert.run('Welcome Bonus 100%', 'First deposit doubled up to 50,000 MMK', null, 'Claim', '#', 1);
    insert.run('Daily Check-in',     'Login daily to earn up to 5,000 MMK',     null, 'Check in', '#', 2);
    insert.run('VIP Cashback',       'Up to 2.0% daily rebate on losses',       null, 'Join VIP',  '#', 3);
    insert.run('Refer & Earn',       'Invite friends, earn 500 MMK per signup',  null, 'Copy link', '#', 4);
  }

  const winnersCount = db.prepare('SELECT COUNT(*) as c FROM winners').get().c;
  if (winnersCount === 0) {
    const insert = db.prepare(`
      INSERT INTO winners (date, name, prize, currency, period_id, market, avatar_url)
      VALUES (date('now'), ?, ?, 'MMK', ?, ?, ?)
    `);
    const samples = [
      ['Ko***',     1250000, '20260807-0098', 'WinGo',  null],
      ['Ma***',      890000, 'TRX-20260807-0089', 'WinTrx', null],
      ['Aung***',    750000, '20260807-0097', 'WinGo',  null],
      ['Kyaw***',    625000, '20260807-0096', 'WinGo',  null],
      ['Zaw***',     580000, 'TRX-20260807-0088', 'WinTrx', null],
      ['Su***',      520000, '20260807-0095', 'WinGo',  null],
      ['Hla***',     480000, '20260807-0094', 'WinGo',  null],
      ['Win***',     450000, 'TRX-20260807-0087', 'WinTrx', null],
      ['Thiri***',   410000, '20260807-0093', 'WinGo',  null],
      ['Mg***',      380000, '20260807-0092', 'WinGo',  null],
    ];
    for (const s of samples) insert.run(...s);
  }
}

seedDefaults();

export default db;
