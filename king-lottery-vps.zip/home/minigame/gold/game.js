/* ============================================================
   Gold Goal — Mines-style reveal game
   ============================================================ */

(function () {
  const GRID_SIZE = 25; // 5x5
  const TILES = 25;

  const state = {
    inGame: false,
    revealed: 0,
    minesCount: 3,
    mines: new Set(),
    multiplier: 1,
    bet: 1000,
    user: null,
    rounds: [],
  };

  const el = {
    grid: document.getElementById('goldGrid'),
    nextMult: document.getElementById('nextMult'),
    minesCount: document.getElementById('minesCount'),
    minesRange: document.getElementById('minesRange'),
    betAmount: document.getElementById('betAmount'),
    startBtn: document.getElementById('startBtn'),
    cashoutBtn: document.getElementById('cashoutBtn'),
    cashoutAmt: document.getElementById('cashoutAmt'),
    gameId: document.getElementById('gameId'),
    roundHistory: document.getElementById('roundHistory'),
    balanceAmount: document.getElementById('balanceAmount'),
  };

  function buildGrid() {
    el.grid.innerHTML = Array.from({ length: TILES }, (_, i) => `
      <button class="gold-cell" data-idx="${i}" disabled>?</button>
    `).join('');

    el.grid.addEventListener('click', e => {
      const cell = e.target.closest('.gold-cell');
      if (!cell || !state.inGame || cell.classList.contains('revealed')) return;
      const idx = Number(cell.dataset.idx);
      reveal(idx);
    });
  }

  function placeMines() {
    state.mines.clear();
    const count = state.minesCount;
    while (state.mines.size < count) {
      const r = Math.floor(Math.random() * TILES);
      state.mines.add(r);
    }
  }

  function computeMultiplier() {
    // Standard mines: f(safe, mines) = (TILES / (TILES - mines)) ** safe
    const safe = state.revealed + 1;
    const m = (TILES / (TILES - state.minesCount)) ** safe;
    return m;
  }

  function refreshMultiplier() {
    const m = computeMultiplier();
    state.multiplier = m;
    el.nextMult.textContent = `${m.toFixed(2)}x`;
    const payout = Math.floor(state.bet * m);
    el.cashoutAmt.textContent = payout.toLocaleString('en-US');
  }

  function reveal(idx) {
    if (state.mines.has(idx)) {
      // Game over
      const cell = el.grid.querySelector(`[data-idx="${idx}"]`);
      cell.classList.add('revealed', 'mine');
      cell.textContent = '✕';
      // Reveal all mines
      el.grid.querySelectorAll('.gold-cell').forEach(c => {
        const i = Number(c.dataset.idx);
        if (state.mines.has(i) && !c.classList.contains('revealed')) {
          c.classList.add('revealed', 'mine');
          c.textContent = '✕';
        }
      });
      window.ui.beep('lose');
      window.ui.modal({
        kind: 'lose',
        title: 'Mine hit!',
        body: `You lost <strong>${state.bet.toLocaleString()} K</strong>.`,
        confirmText: 'Try Again',
      });
      recordRound(false);
      endGame();
      return;
    }
    // Safe
    const cell = el.grid.querySelector(`[data-idx="${idx}"]`);
    cell.classList.add('revealed', 'gem');
    cell.textContent = '💎';
    state.revealed++;
    window.ui.beep('tick');
    refreshMultiplier();
  }

  function startGame() {
    state.user = window.store.getUser() || { balance: 0 };
    state.bet = Math.max(100, Number(el.betAmount.value) || 1000);
    if (state.user.balance < state.bet) {
      window.ui.modal({ kind: 'lose', title: 'Insufficient balance', body: 'Not enough funds.', confirmText: 'OK' });
      return;
    }
    state.user.balance -= state.bet;
    window.store.setUser(state.user);
    refreshBalance();

    state.minesCount = Number(el.minesRange.value);
    state.revealed = 0;
    state.inGame = true;
    placeMines();

    // Generate game ID
    el.gameId.textContent = `G${Date.now().toString(36).toUpperCase()}`;

    // Reset grid
    el.grid.querySelectorAll('.gold-cell').forEach(c => {
      c.classList.remove('revealed', 'gem', 'mine', 'disabled');
      c.textContent = '?';
      c.disabled = false;
    });

    el.startBtn.classList.add('hidden');
    el.cashoutBtn.classList.remove('hidden');
    el.minesRange.disabled = true;
    el.betAmount.disabled = true;

    refreshMultiplier();
  }

  function cashout() {
    if (!state.inGame) return;
    const payout = Math.floor(state.bet * state.multiplier);
    state.user.balance += payout;
    window.store.setUser(state.user);
    refreshBalance();

    window.ui.beep('win');
    window.ui.modal({
      kind: 'win',
      title: 'You won!',
      body: `<strong style="font-size: var(--fs-3xl); color: var(--brand); font-family: var(--font-num);">+${payout.toLocaleString()} K</strong><br><span style="color: var(--text-2); font-size: var(--fs-sm);">${state.revealed} gems · ${state.multiplier.toFixed(2)}x</span>`,
      confirmText: 'OK',
    });
    recordRound(true, payout);
    endGame();
  }

  function endGame() {
    state.inGame = false;
    el.startBtn.classList.remove('hidden');
    el.cashoutBtn.classList.add('hidden');
    el.minesRange.disabled = false;
    el.betAmount.disabled = false;
    el.grid.querySelectorAll('.gold-cell').forEach(c => c.disabled = true);
  }

  function recordRound(won, payout = 0) {
    state.rounds.unshift({ ts: Date.now(), bet: state.bet, won, payout, mult: state.multiplier, mines: state.minesCount });
    if (state.rounds.length > 10) state.rounds.length = 10;
    el.roundHistory.innerHTML = state.rounds.map(r => `
      <div style="display: flex; align-items: center; gap: var(--sp-2); padding: var(--sp-2) 0; border-bottom: 1px solid var(--line-soft);">
        <span style="color: ${r.won ? 'var(--green)' : 'var(--red)'}; font-weight: 700;">${r.won ? '✓' : '✕'}</span>
        <span style="flex: 1;">${r.mines} mines · ${r.mult.toFixed(2)}x · ${r.bet.toLocaleString()} K</span>
        <span style="font-family: var(--font-num); font-weight: 700; color: ${r.won ? 'var(--green)' : 'var(--red)'};">
          ${r.won ? '+' : ''}${r.payout.toLocaleString()} K
        </span>
      </div>
    `).join('');
  }

  function refreshBalance() {
    state.user = window.store.getUser() || { balance: 0 };
    if (el.balanceAmount) el.balanceAmount.textContent = state.user.balance.toLocaleString('en-US');
  }

  function initLang() {
    const btn = document.getElementById('langToggle');
    if (!btn) return;
    const refresh = () => { btn.textContent = window.i18n.getLang() === 'my' ? 'EN' : 'မြန်'; };
    refresh();
    btn.addEventListener('click', () => {
      window.i18n.setLang(window.i18n.getLang() === 'my' ? 'en' : 'my');
      refresh();
    });
  }

  document.addEventListener('DOMContentLoaded', () => {
    state.user = window.store.getUser() || { id: 'demo', name: 'Demo', balance: 100000, vipTier: 'gold' };
    window.store.setUser(state.user);

    window.i18n.applyTranslations();
    initLang();
    buildGrid();
    refreshBalance();

    el.minesRange.addEventListener('input', () => {
      state.minesCount = Number(el.minesRange.value);
      el.minesCount.textContent = state.minesCount;
    });

    el.betAmount.addEventListener('input', () => {
      state.bet = Math.max(100, Number(el.betAmount.value) || 1000);
    });

    el.startBtn.addEventListener('click', startGame);
    el.cashoutBtn.addEventListener('click', cashout);
  });
})();