/* ============================================================
   WinGo 1Min — game logic
   ============================================================ */

(function () {
  const t = window.i18n.t;

  // State
  const state = {
    betType: '2d',
    multiplier: 1,
    selections: [],   // [{value, type}]
    history: [],
    currentPeriod: null,
    user: null,
    isRevealing: false,
  };

  // ── DOM ──────────��────────────────────────────
  const el = {
    periodId:        document.getElementById('periodId'),
    cdMm:            document.getElementById('cd-mm'),
    cdSs:            document.getElementById('cd-ss'),
    cdBox:           document.getElementById('countdown'),
    status:          document.getElementById('gameStatus'),
    recent:          document.getElementById('recentResults'),
    numberGrid:      document.getElementById('numberGrid'),
    pickerArea:      document.getElementById('pickerArea'),
    colorPicker:     document.getElementById('colorPicker'),
    sizePicker:      document.getElementById('sizePicker'),
    parityPicker:    document.getElementById('parityPicker'),
    slipBody:        document.getElementById('betSlipBody'),
    slipTotal:       document.getElementById('betSlipTotal'),
    totalAmount:     document.getElementById('totalAmount'),
    placeBet:        document.getElementById('placeBet'),
    clearSlip:       document.getElementById('clearSlip'),
    historyTable:    document.getElementById('historyTable'),
    trendSize:       document.getElementById('trendSize'),
    trendParity:     document.getElementById('trendParity'),
    trendColor:      document.getElementById('trendColor'),
    balanceAmount:   document.getElementById('balanceAmount'),
  };

  // ── Number grid (00-99) ───────────────────────
  function buildNumberGrid() {
    const cells = [];
    for (let i = 0; i < 100; i++) {
      const num = String(i).padStart(2, '0');
      const color = i % 10 === 0 || i % 10 === 5 ? 'violet'
                   : i % 2 === 0 ? (i % 4 === 0 ? 'violet' : 'red')
                   : 'green';
      cells.push(`
        <button class="num-cell ${i === 0 ? 'color-violet' : ''}" data-num="${num}" data-color="${color}">
          ${num}
        </button>
      `);
    }
    el.numberGrid.innerHTML = cells.join('');
    el.numberGrid.addEventListener('click', e => {
      const cell = e.target.closest('.num-cell');
      if (!cell) return;
      const num = cell.dataset.num;
      toggleSelection(num);
      cell.classList.toggle('selected');
    });
  }

  function toggleSelection(num) {
    const idx = state.selections.findIndex(s => s.value === num);
    if (idx >= 0) state.selections.splice(idx, 1);
    else state.selections.push({ value: num, type: '2d' });
    renderSlip();
  }

  // ── Bet-type tab switcher ─────────────────────
  function initBetTypeTabs() {
    document.querySelectorAll('[data-bettype]').forEach(tab => {
      tab.addEventListener('click', () => {
        document.querySelectorAll('[data-bettype]').forEach(x => x.classList.toggle('active', x === tab));
        state.betType = tab.dataset.bettype;
        state.selections = [];
        renderSlip();

        const is2D = state.betType === '2d';
        el.numberGrid.style.display = is2D ? '' : 'none';
        el.pickerArea.classList.toggle('hidden', is2D);
        el.colorPicker.classList.toggle('hidden', state.betType !== 'color');
        el.sizePicker.classList.toggle('hidden', state.betType !== 'size');
        el.parityPicker.classList.toggle('hidden', state.betType !== 'parity');

        // Hook picker clicks
        if (!is2D) {
          document.querySelectorAll('[data-val]').forEach(btn => {
            btn.onclick = () => {
              const v = btn.dataset.val;
              const idx = state.selections.findIndex(s => s.value === v);
              if (idx >= 0) {
                state.selections.splice(idx, 1);
                btn.classList.remove('active');
              } else {
                state.selections.push({ value: v, type: state.betType });
                btn.classList.add('active');
              }
              renderSlip();
            };
          });
        }
      });
    });
  }

  // ── Multiplier chips ──────────────────────────
  function initMultipliers() {
    document.querySelectorAll('[data-mult]').forEach(chip => {
      chip.addEventListener('click', () => {
        document.querySelectorAll('[data-mult]').forEach(c => c.classList.toggle('active', c === chip));
        state.multiplier = Number(chip.dataset.mult);
        renderSlip();
      });
    });
  }

  // ── Render slip ───────────────────────────────
  function renderSlip() {
    if (state.selections.length === 0) {
      el.slipBody.innerHTML = `<div class="bet-slip-empty">${t('wingo.bet.empty', 'ဂဏန်း ရွေးပါ')}</div>`;
      el.slipTotal.style.display = 'none';
      el.placeBet.style.display = 'none';
      return;
    }

    const amount = 1000 * state.multiplier; // 1000 K base per pick
    const total = state.selections.length * amount;

    el.slipBody.innerHTML = state.selections.map(s => `
      <div class="bet-slip-row" data-value="${s.value}">
        <div class="bet-slip-num">${s.value}</div>
        <input class="bet-slip-amt" type="number" value="${amount}" min="100" step="100" data-amount>
        <button class="bet-slip-remove" data-remove="${s.value}">✕</button>
      </div>
    `).join('');

    el.slipTotal.style.display = '';
    el.placeBet.style.display = '';
    el.totalAmount.textContent = `${total.toLocaleString('en-US')} K`;

    // Edit amount
    el.slipBody.querySelectorAll('[data-amount]').forEach(inp => {
      inp.addEventListener('input', () => {
        const v = Math.max(100, Number(inp.value) || 0);
        inp.value = v;
        const sum = [...el.slipBody.querySelectorAll('[data-amount]')].reduce((a, b) => a + Number(b.value), 0);
        el.totalAmount.textContent = `${sum.toLocaleString('en-US')} K`;
      });
    });

    // Remove
    el.slipBody.querySelectorAll('[data-remove]').forEach(btn => {
      btn.addEventListener('click', () => {
        const v = btn.dataset.remove;
        const idx = state.selections.findIndex(s => s.value === v);
        if (idx >= 0) state.selections.splice(idx, 1);
        // De-select in grid
        const cell = el.numberGrid.querySelector(`[data-num="${v}"]`);
        if (cell) cell.classList.remove('selected');
        // De-select in picker
        document.querySelectorAll(`[data-val="${v}"]`).forEach(b => b.classList.remove('active'));
        renderSlip();
      });
    });
  }

  // ── Place bet ────────────────────────────────
  el.placeBet?.addEventListener('click', () => {
    if (!state.user) {
      window.store.setUser({ id: 'demo', name: 'Demo', balance: 100000, vipTier: 'gold' });
      state.user = window.store.getUser();
    }
    if (state.status === 'closed' || state.status === 'revealing') {
      window.ui.toast(t('wingo.waiting', 'စောင့်ဆိုင်းနေသည်'), 'info');
      return;
    }

    // Read amounts
    const amtInputs = [...el.slipBody.querySelectorAll('[data-amount]')];
    const bets = state.selections.map((s, i) => ({
      type: state.betType,
      value: s.value,
      amount: Number(amtInputs[i]?.value) || 1000,
      periodId: state.currentPeriod.periodId,
    }));

    const totalStake = bets.reduce((a, b) => a + b.amount, 0);

    if (state.user.balance < totalStake) {
      window.ui.modal({
        kind: 'lose',
        title: 'Insufficient balance',
        body: `You need ${totalStake.toLocaleString()} K but only have ${state.user.balance.toLocaleString()} K.`,
        confirmText: 'OK',
      });
      return;
    }

    // Decrement balance
    state.user.balance -= totalStake;
    window.store.setUser(state.user);
    refreshBalance();

    // Stash bets for settlement on reveal
    const stash = window.store.getBetslip();
    stash.selections = bets;
    stash.periodId = state.currentPeriod.periodId;
    stash.stake = totalStake;
    window.store.setBetslip(stash);

    window.ui.toast(`Bet placed: ${bets.length} pick(s), ${totalStake.toLocaleString()} K`, 'success');

    // Clear UI
    state.selections = [];
    el.numberGrid.querySelectorAll('.selected').forEach(c => c.classList.remove('selected'));
    document.querySelectorAll('[data-val].active').forEach(b => b.classList.remove('active'));
    renderSlip();
  });

  el.clearSlip?.addEventListener('click', () => {
    state.selections = [];
    el.numberGrid.querySelectorAll('.selected').forEach(c => c.classList.remove('selected'));
    document.querySelectorAll('[data-val].active').forEach(b => b.classList.remove('active'));
    renderSlip();
  });

  // ── Countdown + reveal flow ───────────────────
  function startTicker() {
    window.drawEngine.startCountdown('wingo', tick => {
      state.currentPeriod = tick.period;
      el.periodId.textContent = tick.period.periodId;
      el.cdMm.textContent = tick.mm;
      el.cdSs.textContent = tick.ss;

      // Color status
      el.status.className = `game-status ${tick.status}`;
      el.status.textContent = tick.status === 'open' ? 'Open' : tick.status === 'revealing' ? 'Revealing' : 'Closed';
      el.cdBox.querySelectorAll('.countdown-block').forEach(b => b.classList.toggle('urgent', tick.urgent && tick.status === 'open'));

      state.status = tick.status;

      if (tick.type === 'period-change') {
        // Settle previous period's bets (if any)
        settlePreviousPeriod(tick.period.seq - 1);
      }
    });
  }

  function settlePreviousPeriod(prevSeq) {
    const stash = window.store.getBetslip();
    if (!stash.periodId || !stash.selections || stash.selections.length === 0) return;

    // Was the previous period the one we bet on?
    const prevId = (() => {
      const m = window.drawEngine.markets.wingo;
      const periodStart = m.epochMs + (prevSeq - 1) * m.intervalMs;
      const d = new Date(periodStart);
      const yyyymmdd = `${d.getUTCFullYear()}${String(d.getUTCMonth()+1).padStart(2,'0')}${String(d.getUTCDate()).padStart(2,'0')}`;
      return m.periodFormat({ date: yyyymmdd, seq: prevSeq });
    })();

    if (stash.periodId !== prevId) return;

    const result = window.drawEngine.generateResult(prevId);
    const odds = 95; // 2D payout multiplier

    let totalPayout = 0;
    let wins = 0;
    stash.selections.forEach(bet => {
      const payout = window.drawEngine.settleBet(bet, result, odds);
      if (payout > 0) { wins++; totalPayout += payout; }
    });

    state.user = window.store.getUser() || { balance: 0 };
    state.user.balance += totalPayout;
    window.store.setUser(state.user);
    refreshBalance();

    if (wins > 0) {
      window.ui.modal({
        kind: 'win',
        title: t('wingo.bet.win', 'ပေါ်ပါပြီ!'),
        body: `Result: <strong style="color:var(--brand);font-family:var(--font-num);font-size:24px;">${String(result.num).padStart(2, '0')}</strong> · ${result.color} · ${result.size} · ${result.parity}<br><br>${wins} winning pick(s) · <strong>${totalPayout.toLocaleString('en-US')} K</strong>`,
        confirmText: 'OK',
      });
      window.ui.beep('win');
    }

    // Save to history
    window.store.addHistory({
      periodId: stash.periodId,
      picks: stash.selections.length,
      stake: stash.stake,
      payout: totalPayout,
      result,
    });

    window.store.clearBetslip();
  }

  // ── History / trends ──────────────────────────
  async function loadHistory() {
    // Prefer VPS backend (paginated, real-time). Fall back to bundled mock JSON
    // when the backend is offline (e.g. previewing the static site).
    let draws = [];
    let page = 1;
    if (window.api?.wingo) {
      const r = await window.api.wingo.list(page, 50);
      draws = r.draws || [];
    } else {
      try { draws = await fetch('/data/draws-wingo.json').then(r => r.json()); }
      catch (e) { return; }
    }
    state.history = draws.slice(0, 50);

    el.historyTable.innerHTML = state.history.slice(0, 30).map(d => `
      <tr>
        <td class="mono">${d.periodId.slice(-8)}</td>
        <td><strong>${String(d.num).padStart(2,'0')}</strong></td>
        <td><span class="num-tile color-${d.color}" style="width:24px;height:24px;font-size:var(--fs-xs);">${d.color[0].toUpperCase()}</span></td>
        <td>${d.size === 'big' ? 'ကြီး' : 'သေး'}</td>
        <td>${d.parity === 'even' ? 'စုံ' : 'မြင်'}</td>
      </tr>
    `).join('');

    // Recent 3
    const recent = state.history.slice(0, 3).reverse();
    el.recent.innerHTML = recent.map(d => `
      <div class="recent-result">
        <div class="period">${d.periodId.slice(-8)}</div>
        <div class="result-tile color-${d.color}" style="width: 48px; height: 56px; font-size: var(--fs-2xl);">${String(d.num).padStart(2, '0')}</div>
        <div style="font-size: var(--fs-xs); color: var(--text-2);">${d.color.toUpperCase()}</div>
      </div>
    `).join('');

    // Trends (last 50)
    const last50 = draws.slice(-50);
    el.trendSize.innerHTML = last50.map(d => `<div class="trend-cell ${d.size}"></div>`).join('');
    el.trendParity.innerHTML = last50.map(d => `<div class="trend-cell ${d.size === 'big' ? 'big' : 'small'}" style="height: ${d.parity === 'odd' ? '80%' : '50%'}; background: ${d.parity === 'odd' ? 'var(--brand)' : 'var(--accent)'};"></div>`).join('');
    el.trendColor.innerHTML = last50.map(d => `<div class="trend-cell" style="height: 100%; background: ${d.color === 'violet' ? 'var(--violet)' : d.color === 'red' ? 'var(--red)' : 'var(--green)'};"></div>`).join('');
  }

  // ── Balance ───────────────────────────────────
  function refreshBalance() {
    state.user = window.store.getUser() || { balance: 0 };
    if (el.balanceAmount) {
      el.balanceAmount.textContent = state.user.balance.toLocaleString('en-US');
    }
  }

  // ── Lang ─────────────────────���────────────────
  function initLang() {
    const btn = document.getElementById('langToggle');
    if (!btn) return;
    const refresh = () => { btn.textContent = window.i18n.getLang() === 'my' ? 'EN' : 'မြန်'; };
    refresh();
    btn.addEventListener('click', () => {
      window.i18n.setLang(window.i18n.getLang() === 'my' ? 'en' : 'my');
      refresh();
    });
  }

  // ── Boot ──────────��───────────────────────────
  document.addEventListener('DOMContentLoaded', () => {
    state.user = window.store.getUser() || { id: 'demo', name: 'Demo', balance: 100000, vipTier: 'gold' };
    window.store.setUser(state.user);

    window.i18n.applyTranslations();
    initLang();
    buildNumberGrid();
    initBetTypeTabs();
    initMultipliers();
    refreshBalance();
    renderSlip();
    loadHistory();
    startTicker();
  });
})();