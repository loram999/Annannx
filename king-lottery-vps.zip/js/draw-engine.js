/* ============================================================
   KING LOTTERY — Draw Engine
   Period ID generator, seeded RNG, countdown ticker
   ============================================================ */

// Mulberry32 — small, fast seeded PRNG
function mulberry32(seed) {
  let a = seed >>> 0;
  return function() {
    a = (a + 0x6D2B79F5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// Hash a period ID to a 32-bit integer (stable across reloads)
function hashString(s) {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619) >>> 0;
  }
  return h;
}

const markets = {
  wingo:  { id: 'wingo',  label: 'WinGo',  intervalMs: 60_000,    epochMs: 1_700_000_000_000, periodFormat: p => `${p.date}-${String(p.seq).padStart(4, '0')}` },
  wintrx: { id: 'wintrx', label: 'WinTrx', intervalMs: 60_000,    epochMs: 1_700_000_000_000, periodFormat: p => `TRX-${p.date}-${String(p.seq).padStart(4, '0')}` },
};

function getMarket(id) {
  return markets[id];
}

function getCurrentPeriod(marketId) {
  const m = markets[marketId];
  if (!m) return null;
  const now = Date.now();
  const elapsed = now - m.epochMs;
  const seq = Math.floor(elapsed / m.intervalMs) + 1;
  const periodStart = m.epochMs + (seq - 1) * m.intervalMs;
  const periodEnd   = periodStart + m.intervalMs;
  const date = new Date(periodStart);
  const yyyymmdd = `${date.getUTCFullYear()}${String(date.getUTCMonth()+1).padStart(2,'0')}${String(date.getUTCDate()).padStart(2,'0')}`;
  return {
    market: marketId,
    seq,
    date: yyyymmdd,
    periodId: m.periodFormat({ date: yyyymmdd, seq }),
    periodStart,
    periodEnd,
    msLeft: Math.max(0, periodEnd - now),
  };
}

function generateResult(periodId) {
  const seed = hashString(periodId);
  const rng = mulberry32(seed);
  const num = Math.floor(rng() * 100); // 0-99

  // Color: 0,5,10,15,... etc. violet; 1,3,7,9,... red; 2,4,6,8,... green
  let color = 'red';
  if (num % 2 === 0) color = (num % 4 === 0) ? 'violet' : 'red';
  else                color = 'green';
  if (num === 0 || num === 5) color = 'violet';

  const size   = num >= 50 ? 'big' : 'small';
  const parity = num % 2 === 0 ? 'even' : 'odd';

  return { num, color, size, parity };
}

function startCountdown(marketId, onTick) {
  const m = markets[marketId];
  let timer = null;
  let lastPeriodId = null;

  function tick() {
    const cur = getCurrentPeriod(marketId);
    if (!cur) return;

    // Reset slip when period changes
    if (lastPeriodId !== null && lastPeriodId !== cur.periodId) {
      onTick({ type: 'period-change', period: cur });
    }
    lastPeriodId = cur.periodId;

    const totalSec = Math.max(0, Math.floor(cur.msLeft / 1000));
    const mm = String(Math.floor(totalSec / 60)).padStart(2, '0');
    const ss = String(totalSec % 60).padStart(2, '0');
    const urgent = cur.msLeft <= 10_000;

    let status = 'open';
    if (cur.msLeft <= 0)            status = 'closed';
    else if (cur.msLeft <= 5_000)   status = 'revealing';

    onTick({
      type: 'tick',
      period: cur,
      mm,
      ss,
      mmss: `${mm}:${ss}`,
      urgent,
      status,
    });
  }

  tick();
  timer = setInterval(tick, 250);
  return () => clearInterval(timer);
}

function generateHistory(marketId, count = 50) {
  // Generate `count` past results from previous periods
  const m = markets[marketId];
  if (!m) return [];
  const cur = getCurrentPeriod(marketId);
  const history = [];
  for (let i = 0; i < count; i++) {
    const seq = cur.seq - i - 1;
    if (seq < 1) break;
    const periodStart = m.epochMs + (seq - 1) * m.intervalMs;
    const date = new Date(periodStart);
    const yyyymmdd = `${date.getUTCFullYear()}${String(date.getUTCMonth()+1).padStart(2,'0')}${String(date.getUTCDate()).padStart(2,'0')}`;
    const periodId = m.periodFormat({ date: yyyymmdd, seq });
    const r = generateResult(periodId);
    history.push({
      periodId,
      ...r,
      ts: periodStart,
    });
  }
  return history;
}

// Settlement: returns payouts for a bet array given a winning result
function settleBet(bet, result, odds) {
  // odds = multiplier (e.g., 95 = 95x for 2D, 3x for color)
  let hit = false;
  let multiplier = 0;

  if (bet.type === '2d') {
    hit = String(bet.value).padStart(2, '0') === String(result.num).padStart(2, '0');
    multiplier = hit ? odds : 0;
  } else if (bet.type === 'color') {
    hit = bet.value === result.color;
    multiplier = hit ? 3 : 0;
  } else if (bet.type === 'size') {
    hit = bet.value === result.size;
    multiplier = hit ? 2 : 0;
  } else if (bet.type === 'parity') {
    hit = bet.value === result.parity;
    multiplier = hit ? 2 : 0;
  }

  return hit ? bet.amount * multiplier : 0;
}

window.drawEngine = {
  markets,
  getMarket,
  getCurrentPeriod,
  generateResult,
  generateHistory,
  startCountdown,
  settleBet,
};