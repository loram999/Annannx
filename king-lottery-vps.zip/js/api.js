/* ============================================================
   KING LOTTERY — Frontend API client
   All calls go to /api/* Vercel Functions. Secrets stay server-side.
   Falls back to local mock data when /api/* is unreachable or returns an error.
   ============================================================ */

(function () {
  const cfg  = window.CONFIG;
  const ui   = window.ui;
  const t    = window.i18n.t;
  const store = window.store;

  // ── Auth token storage ─────────────────────────────────
  const TOKENS = {
    get access_token()  { return localStorage.getItem('king.api.access_token');  },
    set access_token(v) { localStorage.setItem('king.api.access_token', v || ''); },
    get refresh_token() { return localStorage.getItem('king.api.refresh_token'); },
    set refresh_token(v){ localStorage.setItem('king.api.refresh_token', v || ''); },
    clear() {
      localStorage.removeItem('king.api.access_token');
      localStorage.removeItem('king.api.refresh_token');
    },
  };

  // ── HTTP helper ────────────────────────────────────────
  async function http(path, opts = {}) {
    const { method = 'GET', body, auth = false } = opts;
    const url = cfg.API_BASE + path;
    const headers = { 'Content-Type': 'application/json' };
    if (auth && TOKENS.access_token) {
      headers['Authorization'] = `Bearer ${TOKENS.access_token}`;
    }
    if (cfg.DEBUG_API) console.log(`[API] ${method} ${url}`, body);
    const res = await fetch(url, {
      method,
      headers,
      body: body ? JSON.stringify(body) : undefined,
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      const err = new Error(data.error || `HTTP ${res.status}`);
      err.status = res.status;
      err.data = data;
      throw err;
    }
    return data;
  }

  // ── Auth ───────────────────────────────────────────────
  const auth = {
    async login(phone, password) {
      const data = await http('/auth/login', { method: 'POST', body: { phone, password } });
      TOKENS.access_token  = data.access_token;
      TOKENS.refresh_token = data.refresh_token;
      // Hydrate profile
      try {
        const profile = await this.fetchProfile();
        store.setUser({ id: data.user.id, phone: data.user.phone, ...(profile || {}) });
      } catch {
        store.setUser({ id: data.user.id, phone: data.user.phone, balance: 0, vipTier: 'bronze' });
      }
      return data.user;
    },

    async register({ phone, password, inviteCode, nickname, country }) {
      const data = await http('/auth/register', {
        method: 'POST',
        body: { phone, password, inviteCode, nickname, country },
      });
      if (data.access_token) {
        TOKENS.access_token  = data.access_token;
        TOKENS.refresh_token = data.refresh_token;
      }
      store.setUser({ id: data.user.id, phone: data.user.phone, balance: 0, vipTier: 'bronze' });
      return data.user;
    },

    async logout() {
      try { await http('/auth/logout', { method: 'POST', auth: true }); } catch (_) {}
      TOKENS.clear();
      store.logout();
    },

    async refresh() {
      if (!TOKENS.refresh_token) return null;
      try {
        const data = await http('/auth/refresh', { method: 'POST', body: { refresh_token: TOKENS.refresh_token } });
        TOKENS.access_token  = data.access_token;
        TOKENS.refresh_token = data.refresh_token;
        return data.user;
      } catch (_) {
        TOKENS.clear();
        return null;
      }
    },

    isAuthenticated() { return !!TOKENS.access_token; },

    async fetchProfile() {
      const data = await http('/profile', { method: 'GET', auth: true });
      return data.profile;
    },
  };

  // ── Profile ────────────────────────────────────────────
  const profile = {
    async get() {
      try {
        const data = await http('/profile', { method: 'GET', auth: true });
        return data.profile;
      } catch (e) {
        if (!cfg.USE_MOCK_FALLBACK) throw e;
        return store.getUser();
      }
    },

    async update(patch) {
      const data = await http('/profile', { method: 'PATCH', auth: true, body: patch });
      return data.profile;
    },
  };

  // ── Winners ────────────────────────────────────────────
  const winners = {
    async getToday() {
      try {
        return await http('/winners', { method: 'GET' });
      } catch (e) {
        if (!cfg.USE_MOCK_FALLBACK) throw e;
        const r = await fetch('/data/winners.json');
        return { winners: await r.json(), mock: true };
      }
    },
  };

  // ── Wallet ─────────────────────────────────────────────
  const wallet = {
    async getGateways() {
      try {
        return await http('/wallet/gateways', { method: 'GET' });
      } catch (e) {
        if (!cfg.USE_MOCK_FALLBACK) throw e;
        return {
          gateways: [
            { id: 'kbz',  name: 'KBZ Pay',    icon: '/png/payment-kbz.svg',   min: 1000,  max: 1000000 },
            { id: 'wave', name: 'Wave Money', icon: '/png/payment-wave.svg',  min: 1000,  max: 500000  },
            { id: 'aya',  name: 'AYA Pay',    icon: '/png/payment-aya.svg',   min: 5000,  max: 2000000 },
            { id: 'omt',  name: 'OMT',        icon: '/png/payment-omt.svg',   min: 1000,  max: 300000  },
            { id: 'usdt', name: 'USDT-TRC20', icon: '/png/payment-usdt.svg',  min: 10000, max: 5000000 },
          ],
          mock: true,
        };
      }
    },

    async submitDeposit(payload) {
      return http('/wallet/deposit', { method: 'POST', auth: true, body: payload });
    },

    async submitWithdraw(payload) {
      return http('/wallet/withdraw', { method: 'POST', auth: true, body: payload });
    },

    async getDepositHistory() {
      try { return await http('/wallet/history?type=deposits', { method: 'GET', auth: true }); }
      catch (e) { if (!cfg.USE_MOCK_FALLBACK) throw e; return { deposits: [] }; }
    },

    async getWithdrawHistory() {
      try { return await http('/wallet/history?type=withdraws', { method: 'GET', auth: true }); }
      catch (e) { if (!cfg.USE_MOCK_FALLBACK) throw e; return { withdraws: [] }; }
    },
  };

  // ── VIP ──────────────────────────────────��─────────────
  const vip = {
    async getLevel() {
      try {
        return await http('/vip', { method: 'GET', auth: true });
      } catch (e) {
        if (!cfg.USE_MOCK_FALLBACK) throw e;
        const user = store.getUser() || {};
        return { tier: { tier: 'gold', name: 'Gold', rebate: 0.01 }, progress: 0.5, mock: true };
      }
    },

    computeTier(totalWagered) {
      const levels = cfg.VIP_LEVELS;
      let current = levels[0];
      for (const lvl of levels) if (totalWagered >= lvl.minWagered) current = lvl;
      const next = levels[levels.indexOf(current) + 1] || null;
      const progress = next
        ? Math.min(1, (totalWagered - current.minWagered) / (next.minWagered - current.minWagered))
        : 1;
      return { current, next, progress };
    },
  };

  // ── Promotions ──────────────────────────────────────────
  const promos = {
    async getActive() {
      try {
        return await http('/promotions', { method: 'GET' });
      } catch (e) {
        if (!cfg.USE_MOCK_FALLBACK) throw e;
        return { promotions: [], mock: true };
      }
    },
  };

  // ── Draws (WinGo / WinTrx) ──────────────────────────────────
  // When the VPS backend is reachable, paginated history comes from /api/wingo/draws.
  // When it's not, fall back to /data/draws-<market>.json (still loaded by the page).
  async function loadLocalDraws(market, limit = 50) {
    try {
      const r = await fetch(`/data/draws-${market}.json`);
      if (!r.ok) return [];
      const arr = await r.json();
      return arr.slice(-limit).reverse();
    } catch { return []; }
  }

  const wingo = {
    async list(page = 1, limit = 50) {
      try {
        return await http(`/wingo/draws?page=${page}&limit=${limit}`);
      } catch (e) {
        if (!cfg.USE_MOCK_FALLBACK) throw e;
        const draws = await loadLocalDraws('wingo', limit);
        return { page: 1, limit, total: draws.length, totalPages: 1, hasNext: false, hasPrev: false, draws, mock: true };
      }
    },
    async latest(count = 10) {
      try { return await http(`/wingo/latest?count=${count}`); }
      catch (e) {
        if (!cfg.USE_MOCK_FALLBACK) throw e;
        const draws = await loadLocalDraws('wingo', count);
        return { draws, mock: true };
      }
    },
    async stats() {
      try { return await http('/wingo/stats'); }
      catch (e) { if (!cfg.USE_MOCK_FALLBACK) throw e; return { total: 0, lastDrawTs: null, mock: true }; }
    },
  };

  const wintrx = {
    async list(page = 1, limit = 50) {
      try {
        return await http(`/wintrx/draws?page=${page}&limit=${limit}`);
      } catch (e) {
        if (!cfg.USE_MOCK_FALLBACK) throw e;
        const draws = await loadLocalDraws('wintrx', limit);
        return { page: 1, limit, total: draws.length, totalPages: 1, hasNext: false, hasPrev: false, draws, mock: true };
      }
    },
    async latest(count = 10) {
      try { return await http(`/wintrx/latest?count=${count}`); }
      catch (e) {
        if (!cfg.USE_MOCK_FALLBACK) throw e;
        const draws = await loadLocalDraws('wintrx', count);
        return { draws, mock: true };
      }
    },
    async stats() {
      try { return await http('/wintrx/stats'); }
      catch (e) { if (!cfg.USE_MOCK_FALLBACK) throw e; return { total: 0, lastDrawTs: null, mock: true }; }
    },
  };

  // Public API
  window.api = { auth, profile, winners, wallet, vip, promos, wingo, wintrx };
})();
