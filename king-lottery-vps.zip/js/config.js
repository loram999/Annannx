/* ============================================================
   KING LOTTERY — Frontend config
   No secrets here. All backend calls go through /api/*.
   ============================================================ */

const CONFIG = {
  // ── API base ──
  // Default: same-origin /api (served by the VPS backend at /api/*).
  // Override at runtime via:
  //     <script>window.CONFIG = { API_BASE: 'https://king.example.com/api' };</script>
  // …before this file loads.
  API_BASE: '/api',

  // ── Feature flags ──
  USE_MOCK_FALLBACK: true,   // if /api/* fails, use local mock data
  DEBUG_API:         false,  // log all API calls to console

  // ── Branding ──
  BRAND_NAME:        'King Lottery',
  BRAND_TAGLINE:     'Myanmar Premier Online Lottery',

  // ── VIP tiers (mirror backend) ──
  VIP_LEVELS: [
    { tier: 'bronze',   name: 'Bronze',   minWagered: 0,        rebate: 0.005 },
    { tier: 'silver',   name: 'Silver',   minWagered: 100000,   rebate: 0.007 },
    { tier: 'gold',     name: 'Gold',     minWagered: 500000,   rebate: 0.010 },
    { tier: 'platinum', name: 'Platinum', minWagered: 2000000,  rebate: 0.012 },
    { tier: 'diamond',  name: 'Diamond',  minWagered: 10000000, rebate: 0.015 },
    { tier: 'king',     name: 'King',     minWagered: 50000000, rebate: 0.020 },
  ],
};

window.CONFIG = CONFIG;