/* ============================================================
   KING LOTTERY — UI helpers
   Toast, modal, sound, helpers
   ============================================================ */

const ui = {
  // ── Toast ──────────────────────────────────────
  toast(msg, kind = 'info', ms = 2400) {
    let stack = document.querySelector('.toast-stack');
    if (!stack) {
      stack = document.createElement('div');
      stack.className = 'toast-stack';
      document.body.appendChild(stack);
    }
    const t = document.createElement('div');
    t.className = `toast ${kind}`;
    const icon = kind === 'success' ? '✓' : kind === 'danger' ? '✕' : 'ℹ';
    t.innerHTML = `<span class="icon">${icon}</span><span>${msg}</span>`;
    stack.appendChild(t);
    setTimeout(() => {
      t.style.opacity = '0';
      t.style.transform = 'translateY(-10px)';
      t.style.transition = 'all 200ms ease';
      setTimeout(() => t.remove(), 220);
    }, ms);
  },

  // ── Modal ──────────────────────────────────────
  modal(opts) {
    const { title, body, confirmText, cancelText, onConfirm, onCancel, kind = 'default' } = opts;

    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';

    const iconHtml = kind === 'win'
      ? `<div style="text-align:center;font-size:48px;color:var(--brand);margin-bottom:var(--sp-3);">🏆</div>`
      : kind === 'lose'
      ? `<div style="text-align:center;font-size:48px;color:var(--red);margin-bottom:var(--sp-3);">✕</div>`
      : '';

    overlay.innerHTML = `
      <div class="modal">
        ${iconHtml}
        ${title ? `<div class="modal-title">${title}</div>` : ''}
        <div class="modal-body">${body || ''}</div>
        <div class="modal-actions">
          ${cancelText ? `<button class="btn btn-ghost" data-act="cancel">${cancelText}</button>` : ''}
          ${confirmText ? `<button class="btn btn-primary" data-act="confirm">${confirmText}</button>` : ''}
        </div>
      </div>
    `;

    document.body.appendChild(overlay);

    function close() {
      overlay.style.opacity = '0';
      setTimeout(() => overlay.remove(), 200);
    }

    overlay.addEventListener('click', e => {
      if (e.target === overlay) {
        if (onCancel) onCancel();
        close();
      }
    });

    overlay.querySelector('[data-act="confirm"]')?.addEventListener('click', () => {
      if (onConfirm) onConfirm();
      close();
    });
    overlay.querySelector('[data-act="cancel"]')?.addEventListener('click', () => {
      if (onCancel) onCancel();
      close();
    });

    return { close, el: overlay };
  },

  // ── Sound (WebAudio API beep) ───────────────────
  beep(kind = 'tick') {
    const settings = window.store?.getSettings() || { sound: true };
    if (!settings.sound) return;
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);

      if (kind === 'tick') {
        osc.frequency.value = 800;
        gain.gain.value = 0.05;
      } else if (kind === 'win') {
        osc.frequency.value = 1200;
        gain.gain.value = 0.1;
      } else if (kind === 'lose') {
        osc.frequency.value = 220;
        gain.gain.value = 0.08;
      } else {
        osc.frequency.value = 600;
        gain.gain.value = 0.05;
      }

      osc.start();
      osc.stop(ctx.currentTime + 0.1);
      setTimeout(() => ctx.close(), 200);
    } catch (_) {}
  },

  // ── Number formatting ──────────────────────────
  pad2(n) {
    return String(n).padStart(2, '0');
  },
  pad4(n) {
    return String(n).padStart(4, '0');
  },

  // ── HTML escaping ──────────────────────────────
  esc(s) {
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  },
};

window.ui = ui;