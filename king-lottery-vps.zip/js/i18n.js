/* ============================================================
   KING LOTTERY — i18n
   Burmese (default) + English translations
   ============================================================ */

const dict = {
  my: {
    // Header
    'nav.home':        'ပင်မ',
    'nav.lottery':     'ထီ',
    'nav.live':        'တိုက်ရိုက်',
    'nav.promotions':  'ပရိုမိုးရှင်း',
    'nav.app':         'App',
    'login':           'လော့ဂ်အင်',
    'register':        'မှတ်ပုံတင်',
    'balance':         'လက်ကျန်',

    // Auth modal
    'auth.welcome':      'ပြန်လည်ကြိုဆိုပါသည်',
    'auth.phone':        'ဖုန်းနံပါတ်',
    'auth.password':     'စကားဝှက်',
    'auth.inviteCode':   'ဖိတ်ကြားကုဒ်',
    'auth.nickname':     'နာမည်ပြောင်',
    'auth.country':      'နိုင်ငံ',
    'auth.loginBtn':     'လော့ဂ်အင်ဝင်ရန်',
    'auth.registerBtn':  'မှတ်ပုံတင်ရန်',
    'auth.registerTitle':'အကောင့်အသစ်ဖွင့်ရန်',
    'auth.noAccount':    'အကောင့်မရှိသေးဘူးလား?',
    'auth.haveAccount':  'အကောင့်ရှိပြီးသားလား?',
    'auth.loading':      'ခဏစောင့်ပါ...',
    'auth.loginOk':      'ပြန်လည်ကြိုဆိုပါသည်!',
    'auth.registerOk':   'အကောင့်ဖန်တီးပြီးပါပြီ!',

    // User menu
    'user.deposit':  'ငွေဖြည့်ရန်',
    'user.withdraw': 'ငွေထုတ်ရန်',
    'user.vip':      'VIP အဆင့်',
    'user.history':  'မှတ်တမ်း',
    'user.logout':   'လော့ဂ်အောက်',

    // Home
    'home.hero.kicker':'ကမ္ဘာ့အဆင့်',
    'home.hero.title': 'KING LOTTERY',
    'home.hero.sub':   'ကံကောင်းခြင်းကို ရွေးချယ်ပါ — မိနစ်ပိုင်းလောက်နဲ့ ဂဏန်းပေါ်',
    'home.hero.cta':   'ယခု ကစားပါ',
    'home.banner1.title':  'ကြိုဆိုပါတယ် ၁၀၀% ဘောနပ်စ်',
    'home.banner1.sub':    'ပထမဆုံး ငွေသွင်းမှာ နှစ်ဆ',
    'home.banner1.cta':    'ရယူပါ',
    'home.banner2.title':  'VIP အဖွဲ့ဝင်ပါ',
    'home.banner2.sub':    'နေ့စဉ် ဆုလာဘ်များ',
    'home.banner2.cta':    'ဝင်ရန်',
    'home.banner3.title':  'App ဒေါင်းလုဒ်',
    'home.banner3.sub':    'ပိုမြန်ပိုချောပိုလုံခြုံ',
    'home.banner3.cta':    'ယူပါ',

    'home.live.title':      'တိုက်ရိုက် ထုတ်ပိုးမှု',
    'home.hot.title':        'ပူနွေးနေတဲ့ ဂဏန်းများ',
    'home.games.title':      'ကစားရနိုင်တဲ့ ဂိမ်းများ',
    'home.games.lottery':    'ထီ',
    'home.games.mini':       'မိုင်နီဂိမ်း',
    'home.winners.title':    'ယနေ့ ကံထူးရှင်များ',
    'home.howto.title':      'ဘယ်လို ကစားမလဲ',
    'home.howto.step1':      'မှတ်ပုံတင်',
    'home.howto.step2':      'ငွေသွင်း',
    'home.howto.step3':      'ထိုးကြေးထိုး',
    'home.promos.title':     'ပရိုမိုးရှင်းများ',
    'home.payments.title':   'ငွေပေးချေမှု',

    'home.promo1.title': 'နေ့စဉ် လက်ဆောင်',
    'home.promo1.desc':  'ယနေ့ လက်ဆောင် 5,000 K',
    'home.promo2.title': 'ကြိုဆိုဘောနပ်စ်',
    'home.promo2.desc':  '100% ပထမဆုံး ငွေသွင်း',
    'home.promo3.title': 'မိတ်ဆက်ဘောနပ်စ်',
    'home.promo3.desc':  'သူငယ်ချင်း ၁ ယောက် = 5,000 K',
    'home.promo4.title': 'VIP ဆုလာဘ်',
    'home.promo4.desc':  'နေ့စဉ် 1% ပြန်ပေး',

    'home.viewall': 'အကုန်ကြည့်',

    // Games
    'wingo.title':       'ဝင်ဂို',
    'wingo.subtitle':    'မိနစ် ၁ မိနစ်ထီ',
    'wintrx.title':      'ဝင် TRX',
    'wintrx.subtitle':   'TRX ပွိုင့်ထီ',
    'gold.title':        'ရွှေ',
    'gold.subtitle':     'မိုင်နီဂိမ်း',

    'wingo.period':    'အကျော့',
    'wingo.history':   'ထုတ်ပိုးမှု မှတ်တမ်း',
    'wingo.bet.type':  'ထိုးကြေး အမျိုးအစား',
    'wingo.bet.2d':    '2D',
    'wingo.bet.color': 'အရောင်',
    'wingo.bet.size':  'ကြီး/သေး',
    'wingo.bet.parity':'စုံ/မြင်',
    'wingo.bet.confirm':   'ထိုးမည်',
    'wingo.bet.slip':      'ဘတ်ဂျက်',
    'wingo.bet.empty':     'ဂဏန်း ရွေးပါ',
    'wingo.bet.total':     'စုစုပေါင်း',
    'wingo.bet.place':     'ထိုးမည်',
    'wingo.bet.cancel':    'ပယ်ဖျက်',
    'wingo.bet.multiplier':'အကျိုးဆက်',
    'wingo.bet.amount':    'ပမာဏ',
    'wingo.bet.win':       'ပေါ်ပါပြီ!',
    'wingo.bet.lose':      'မပေါ်ပါ',
    'wingo.trend.big':     'ကြီး',
    'wingo.trend.small':   'သေး',
    'wingo.trend.odd':     'မြင်',
    'wingo.trend.even':    'စုံ',
    'wingo.revealing':     'ထုတ်ပိုးနေသည်...',
    'wingo.waiting':       'စောင့်ဆိုင်းနေသည်',

    'gold.start':          'စတင်မည်',
    'gold.cashout':        'ငွေထုတ်မည်',
    'gold.mines':          'မိုင်း အရေအတွက်',
    'gold.field':          'အကွက်',
    'gold.next':           'နောက်',
    'gold.lose':           'မိုင်း ထိပါပြီ',
    'gold.win':            'အနိုင်ရပါပြီ!',
    'gold.bet.amount':     'ထိုးကြေး',

    // Common
    'close':      'ပိတ်',
    'confirm':    'အတည်ပြု',
    'cancel':     'ပယ်ဖျက်',
    'yes':        'ဟုတ်',
    'no':         'မဟုတ်',
    'loading':    'ဖွင့်နေသည်...',
    'success':    'အောင်မြင်ပါပြီ',
    'failed':     'မအောင်မြင်ပါ',
    'language':   'ဘာသာ',

    // Footer
    'footer.about':      'ကျွန်တော်တို့အကြောင်း',
    'footer.terms':      'စည်းမျဉ်းစည်းကမ်း',
    'footer.privacy':    'ကိုယ်ရေးကိုယ်တာ',
    'footer.contact':    'ဆက်သွယ်ရန်',
    'footer.help':       'အကူအညီ',
    'footer.support':    'ပံ့ပိုးမှု',
    'footer.license':    'လိုင်စင်',
    'footer.copyright':  '© 2026 King Lottery. မူပိုင်ခွင့် ရှိပါသည်။',

    'play':        'ကစားပါ',
    'viewMore':    'ပိုမိုကြည့်ရှု',
    'live':        'တိုက်ရိုက်',
    'popular':     'ရေပြင်ကျယ်',
    'hot':         'ပူနွေး',
    'new':         'အသစ်',
  },

  en: {
    'nav.home':        'Home',
    'nav.lottery':     'Lottery',
    'nav.live':        'Live',
    'nav.promotions':  'Promotions',
    'nav.app':         'App',
    'login':           'Login',
    'register':        'Register',
    'balance':         'Balance',

    // Auth modal
    'auth.welcome':      'Welcome back',
    'auth.phone':        'Phone number',
    'auth.password':     'Password',
    'auth.inviteCode':   'Invite code',
    'auth.nickname':     'Nickname',
    'auth.country':      'Country',
    'auth.loginBtn':     'Log in',
    'auth.registerBtn':  'Register',
    'auth.registerTitle':'Create new account',
    'auth.noAccount':    "Don't have an account?",
    'auth.haveAccount':  'Already have an account?',
    'auth.loading':      'Loading...',
    'auth.loginOk':      'Welcome back!',
    'auth.registerOk':   'Account created!',

    // User menu
    'user.deposit':  'Deposit',
    'user.withdraw': 'Withdraw',
    'user.vip':      'VIP Level',
    'user.history':  'History',
    'user.logout':   'Logout',

    'home.hero.kicker':'World Class',
    'home.hero.title': 'KING LOTTERY',
    'home.hero.sub':   'Pick your fortune — a number comes out every minute',
    'home.hero.cta':   'Play Now',
    'home.banner1.title':  'Welcome Bonus 100%',
    'home.banner1.sub':    'Double your first deposit',
    'home.banner1.cta':    'Claim',
    'home.banner2.title':  'Join VIP',
    'home.banner2.sub':    'Daily rewards await',
    'home.banner2.cta':    'Enter',
    'home.banner3.title':  'Download App',
    'home.banner3.sub':    'Faster, smoother, safer',
    'home.banner3.cta':    'Get it',

    'home.live.title':      'Live Draws',
    'home.hot.title':        'Hot Numbers',
    'home.games.title':      'Featured Games',
    'home.games.lottery':    'Lottery',
    'home.games.mini':       'Mini Games',
    'home.winners.title':    "Today's Winners",
    'home.howto.title':      'How to Play',
    'home.howto.step1':      'Register',
    'home.howto.step2':      'Deposit',
    'home.howto.step3':      'Place Bet',
    'home.promos.title':     'Promotions',
    'home.payments.title':   'Payment Methods',

    'home.promo1.title': 'Daily Gift',
    'home.promo1.desc':  'Get 5,000 K today',
    'home.promo2.title': 'Welcome Bonus',
    'home.promo2.desc':  '100% first deposit',
    'home.promo3.title': 'Refer a Friend',
    'home.promo3.desc':  'Earn 5,000 K each',
    'home.promo4.title': 'VIP Reward',
    'home.promo4.desc':  'Daily 1% rebate',

    'home.viewall': 'View all',

    'wingo.title':       'WinGo',
    'wingo.subtitle':    '1-minute lottery',
    'wintrx.title':      'WinTrx',
    'wintrx.subtitle':   'TRX public-chain lottery',
    'gold.title':        'Gold',
    'gold.subtitle':     'Mini Game',

    'wingo.period':    'Period',
    'wingo.history':   'Draw History',
    'wingo.bet.type':  'Bet Type',
    'wingo.bet.2d':    '2D',
    'wingo.bet.color': 'Color',
    'wingo.bet.size':  'Big/Small',
    'wingo.bet.parity':'Odd/Even',
    'wingo.bet.confirm':   'Confirm',
    'wingo.bet.slip':      'Bet Slip',
    'wingo.bet.empty':     'Pick a number',
    'wingo.bet.total':     'Total Stake',
    'wingo.bet.place':     'Place Bet',
    'wingo.bet.cancel':    'Cancel',
    'wingo.bet.multiplier':'Multiplier',
    'wingo.bet.amount':    'Amount',
    'wingo.bet.win':       'You won!',
    'wingo.bet.lose':      'No win',
    'wingo.trend.big':     'Big',
    'wingo.trend.small':   'Small',
    'wingo.trend.odd':     'Odd',
    'wingo.trend.even':    'Even',
    'wingo.revealing':     'Revealing...',
    'wingo.waiting':       'Waiting',

    'gold.start':          'Start',
    'gold.cashout':        'Cash Out',
    'gold.mines':          'Mines',
    'gold.field':          'Field',
    'gold.next':           'Next',
    'gold.lose':           'Hit a mine',
    'gold.win':            'You won!',
    'gold.bet.amount':     'Bet Amount',

    'close':      'Close',
    'confirm':    'Confirm',
    'cancel':     'Cancel',
    'yes':        'Yes',
    'no':         'No',
    'loading':    'Loading...',
    'success':    'Success',
    'failed':     'Failed',
    'language':   'Language',

    'footer.about':      'About Us',
    'footer.terms':      'Terms',
    'footer.privacy':    'Privacy',
    'footer.contact':    'Contact',
    'footer.help':       'Help',
    'footer.support':    'Support',
    'footer.license':    'Licensed',
    'footer.copyright':  '© 2026 King Lottery. All rights reserved.',

    'play':        'Play',
    'viewMore':    'View More',
    'live':        'Live',
    'popular':     'Popular',
    'hot':         'Hot',
    'new':         'New',
  },
};

const STORAGE_KEY = 'king.lang';

function getLang() {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored && dict[stored]) return stored;
  } catch (_) {}
  return 'my';
}

function setLang(lang) {
  if (!dict[lang]) return;
  try { localStorage.setItem(STORAGE_KEY, lang); } catch (_) {}
  applyTranslations();
  document.documentElement.lang = lang === 'my' ? 'my' : 'en';
  // Notify listeners
  document.dispatchEvent(new CustomEvent('langchange', { detail: { lang } }));
}

function t(key, fallback) {
  const lang = getLang();
  return (dict[lang] && dict[lang][key]) || fallback || key;
}

function applyTranslations() {
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    el.textContent = t(key, el.textContent);
  });
  document.querySelectorAll('[data-i18n-attr]').forEach(el => {
    const mapping = el.getAttribute('data-i18n-attr');
    mapping.split(';').forEach(pair => {
      const [attr, key] = pair.split(':').map(s => s.trim());
      if (attr && key) el.setAttribute(attr, t(key));
    });
  });
}

window.i18n = { t, getLang, setLang, applyTranslations };