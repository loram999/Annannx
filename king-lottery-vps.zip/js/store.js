/* ============================================================
   KING LOTTERY — Store
   localStorage wrapper for user, betslip, history
   ============================================================ */

const KEYS = {
  USER:     'king.user',
  BETSLIP:  'king.betslip',
  HISTORY:  'king.history',
  LANG:     'king.lang',
  SETTINGS: 'king.settings',
};

function read(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch (_) {
    return fallback;
  }
}

function write(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch (_) {
    return false;
  }
}

const store = {
  // User / session
  getUser() {
    return read(KEYS.USER, null);
  },
  setUser(user) {
    return write(KEYS.USER, user);
  },
  logout() {
    try {
      localStorage.removeItem(KEYS.USER);
      localStorage.removeItem(KEYS.BETSLIP);
    } catch (_) {}
  },
  isLoggedIn() {
    return !!this.getUser();
  },

  // Bet slip
  getBetslip() {
    return read(KEYS.BETSLIP, { selections: [], stake: 0, periodId: null });
  },
  setBetslip(slip) {
    return write(KEYS.BETSLIP, slip);
  },
  clearBetslip() {
    return write(KEYS.BETSLIP, { selections: [], stake: 0, periodId: null });
  },

  // History
  getHistory() {
    return read(KEYS.HISTORY, []);
  },
  addHistory(entry) {
    const history = this.getHistory();
    history.unshift({ ...entry, ts: Date.now() });
    if (history.length > 200) history.length = 200;
    return write(KEYS.HISTORY, history);
  },

  // Settings
  getSettings() {
    return read(KEYS.SETTINGS, { sound: true, odds: '95' });
  },
  setSettings(s) {
    return write(KEYS.SETTINGS, s);
  },

  // Currency formatter (uses Burmese numerals when lang=my)
  formatAmount(n, opts = {}) {
    const { withSymbol = true } = opts;
    const lang = (window.i18n && window.i18n.getLang()) || 'my';
    const numStr = Number(n).toLocaleString('en-US', { maximumFractionDigits: 0 });
    if (!withSymbol) return lang === 'my' ? this._toBurmeseDigits(numStr) : numStr;
    return (lang === 'my' ? this._toBurmeseDigits(numStr) : numStr) + ' K';
  },

  _burmeseDigits: ['၀','၁','၂','၃','၄','၅','၆','၇','၈','၉'],
  _toBurmeseDigits(str) {
    return String(str).replace(/[0-9]/g, d => this._burmeseDigits[Number(d)]);
  },
};

window.store = store;