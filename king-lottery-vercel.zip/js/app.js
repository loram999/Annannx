/* ============================================================
   KING LOTTERY — Home page wiring
   Live ticker, banner slider, games grid, hot numbers, winners
   ============================================================ */

(function () {
  const t = window.i18n.t;

  // ── Banner slider ────────────────────────────
  function initBanner() {
    const track = document.getElementById('bannerTrack');
    const dots  = document.querySelectorAll('.banner-dot');
    if (!track) return;
    let idx = 0;
    let timer = null;

    function go(i) {
      idx = (i + 3) % 3;
      track.style.transform = `translateX(-${idx * 100}%)`;
      dots.forEach((d, j) => d.classList.toggle('active', j === idx));
    }

    function next() { go(idx + 1); }

    function start() { stop(); timer = setInterval(next, 4000); }
    function stop()  { if (timer) { clearInterval(timer); timer = null; } }

    dots.forEach((d, j) => d.addEventListener('click', () => { go(j); start(); }));
    const slider = document.getElementById('bannerSlider');
    slider?.addEventListener('mouseenter', stop);
    slider?.addEventListener('mouseleave', start);

    start();
  }

  // ── Live ticker ──────────────────────────────
  async function initTicker() {
    const root = document.getElementById('liveTicker');
    if (!root) return;

    let drawsWingo = [], drawsTrx = [];
    try {
      const [a, b] = await Promise.all([
        fetch('/data/draws-wingo.json').then(r => r.json()),
        fetch('/data/draws-wintrx.json').then(r => r.json()),
      ]);
      drawsWingo = a;
      drawsTrx = b;
    } catch (e) {
      console.warn('Failed to load draw data:', e);
      return;
    }

    function render() {
      const recent = [
        ...drawsWingo.slice(-3).map(d => ({ game: 'WinGo',  ...d })),
        ...drawsTrx.slice(-1).map(d => ({ game: 'WinTrx', ...d })),
      ].reverse();

      root.innerHTML = recent.map(d => `
        <div class="ticker-card">
          <div>
            <div class="game">${d.game}</div>
            <div class="period">${d.periodId.slice(-8)}</div>
          </div>
          <div class="nums">
            <span class="num-tile color-${d.color}">${(d.num + '').padStart(2, '0').slice(-1)}</span>
            <span class="num-tile color-${d.color}">${(d.num + '').padStart(2, '0').slice(0, 1)}</span>
          </div>
        </div>
      `).join('');
    }

    render();
    // Refresh every minute
    setInterval(render, 60_000);
  }

  // ── Hot numbers ───────────────────────────────
  async function initHot() {
    const root = document.getElementById('hotGrid');
    if (!root) return;
    let draws = [];
    try { draws = await fetch('/data/draws-wingo.json').then(r => r.json()); }
    catch (e) { return; }

    const recent = draws.slice(-100);
    const freq = {};
    recent.forEach(d => { freq[d.num] = (freq[d.num] || 0) + 1; });

    // Top 12 most-frequent
    const sorted = Object.entries(freq)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 12);

    const maxFreq = sorted[0]?.[1] || 1;
    const minFreq = sorted[sorted.length - 1]?.[1] || 1;
    const mid = (maxFreq + minFreq) / 2;

    root.innerHTML = sorted.map(([num, f]) => {
      const klass = f >= mid + 1 ? 'hot' : f <= mid - 1 ? 'cold' : 'normal';
      const pct = ((f / recent.length) * 100).toFixed(1);
      return `
        <div class="hot-num">
          <div class="hot-num-val ${klass}">${(num + '').padStart(2, '0')}</div>
          <div class="hot-num-pct"><span class="val">${pct}%</span></div>
        </div>
      `;
    }).join('');
  }

  // ── Games grid ────────────────────────────────
  async function initGames() {
    const root = document.getElementById('gamesGrid');
    if (!root) return;
    let markets = [];
    try { markets = await fetch('/data/markets.json').then(r => r.json()); }
    catch (e) { return; }

    const iconMap = {
      wingo:  '/png/games/wingo.svg',
      wingo3: '/png/games/wingo.svg',
      wingo5: '/png/games/wingo.svg',
      wintrx: '/png/games/wintrx.svg',
      gold:   '/png/games/gold.svg',
      dice:   '/png/games/gold.svg',
      slots:  '/png/games/gold.svg',
      aviator:'/png/games/gold.svg',
    };

    const linkMap = {
      wingo:  '/home/alllotterygames/wingo/',
      wintrx: '/home/alllotterygames/wintrx/',
      gold:   '/home/minigame/gold/',
    };

    function render(cat) {
      const list = markets.filter(m => m.category === cat);
      root.innerHTML = list.map(m => {
        const href = linkMap[m.id] || '#';
        const live = m.popular && !m.soon;
        return `
          <a class="game-card" href="${href}" data-cat="${m.category}">
            <img class="game-card-icon-img" src="${iconMap[m.id] || '/png/games/wingo.svg'}" alt="" style="width:48px;height:48px;border-radius:8px;">
            <div>
              <div class="game-card-title">${m.label}</div>
              <div class="game-card-sub">
                ${live ? '<span class="live-dot"></span>' : ''}
                ${m.soon ? 'Coming soon' : (live ? 'Live now' : 'Available')}
              </div>
            </div>
            <div class="game-card-stats">
              <span>${t('play', 'Play')}</span>
              <span class="val">${m.popular ? '🔥 Hot' : 'New'}</span>
            </div>
            <div class="game-card-cta">${t('play', 'Play')}</div>
          </a>
        `;
      }).join('');
    }

    render('lottery');

    document.querySelectorAll('[data-cat]').forEach(tab => {
      tab.addEventListener('click', () => {
        if (!tab.dataset.cat) return;
        document.querySelectorAll('[data-cat]').forEach(x => {
          if (x.classList.contains('tab')) x.classList.toggle('active', x === tab);
        });
        if (tab.classList.contains('tab')) {
          render(tab.dataset.cat);
        }
      });
    });
  }

  // ── Winners ───────────────────────────────────
  async function initWinners() {
    const root = document.getElementById('winnersList');
    if (!root) return;
    let winners = [];
    try { winners = await fetch('/data/winners.json').then(r => r.json()); }
    catch (e) { return; }

    root.innerHTML = winners.slice(0, 12).map(w => `
      <div class="winner-row">
        <div class="winner-avatar">${w.avatar}</div>
        <div class="winner-info">
          <div class="winner-name">${w.name}</div>
          <div class="winner-game">${w.game}</div>
        </div>
        <div class="winner-prize"><span class="currency">K</span>${w.prize.toLocaleString('en-US')}</div>
      </div>
    `).join('');
  }

  // ── Auth buttons (demo) ───────────────────────
  function initAuth() {
    const loginBtn = document.getElementById('loginBtn');
    const regBtn = document.getElementById('registerBtn');
    const pill = document.getElementById('balancePill');
    const amount = document.getElementById('balanceAmount');

    function refresh() {
      const user = window.store.getUser();
      if (user) {
        loginBtn?.classList.add('hidden');
        regBtn?.classList.add('hidden');
        pill?.classList.remove('hidden');
        if (amount) amount.textContent = window.store.formatAmount(user.balance, { withSymbol: false });
      } else {
        loginBtn?.classList.remove('hidden');
        regBtn?.classList.remove('hidden');
        pill?.classList.add('hidden');
      }
    }

    loginBtn?.addEventListener('click', () => {
      window.store.setUser({ id: 'demo', name: 'Demo User', balance: 100000, vipTier: 'gold' });
      window.ui.toast(t('success', 'Success'), 'success');
      refresh();
    });

    regBtn?.addEventListener('click', () => {
      window.store.setUser({ id: 'demo', name: 'Demo User', balance: 100000, vipTier: 'gold' });
      window.ui.toast(t('success', 'Success'), 'success');
      refresh();
    });

    refresh();
  }

  // ── Language toggle ───────────────────────────
  function initLang() {
    const btn = document.getElementById('langToggle');
    if (!btn) return;
    const refresh = () => { btn.textContent = window.i18n.getLang() === 'my' ? 'EN' : 'မြန်'; };
    refresh();
    btn.addEventListener('click', () => {
      window.i18n.setLang(window.i18n.getLang() === 'my' ? 'en' : 'my');
      refresh();
    });
    document.addEventListener('langchange', refresh);
  }

  // ── Boot ──────────────────────────────────────
  document.addEventListener('DOMContentLoaded', () => {
    window.i18n.applyTranslations();
    initLang();
    initAuth();
    initBanner();
    initTicker();
    initHot();
    initGames();
    initWinners();
  });
})();