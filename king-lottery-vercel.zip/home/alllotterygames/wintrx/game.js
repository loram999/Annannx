/* ============================================================
   WinTrx 1Min — game logic
   ============================================================ */

(function () {
  const state = {
    multiplier: 1,
    selections: [],
    user: null,
    currentPeriod: null,
  };

  const el = {
    periodId: document.getElementById('periodId'),
    cdMm: document.getElementById('cd-mm'),
    cdSs: document.getElementById('cd-ss'),
    status: document.getElementById('gameStatus'),
    recent: document.getElementById('recentResults'),
    trxGrid: document.getElementById('trxGrid'),
    slipBody: document.getElementById('betSlipBody'),
    slipTotal: document.getElementById('betSlipTotal'),
    totalAmount: document.getElementById('totalAmount'),
    placeBet: document.getElementById('placeBet'),
    clearSlip: document.getElementById('clearSlip'),
    historyTable: document.getElementById('historyTable'),
    balanceAmount: document.getElementById('balanceAmount'),
    trxHash: document.getElementById('trxHash'),
  };

  // Build 0-9 grid (large buttons)
  function buildTrxGrid() {
    const cells = [];
    for (let i = 0; i < 10; i++) {
      cells.push(`
        <button class="result-tile" data-num="${i}" style="width: 80px; height: 96px; font-size: var(--fs-5xl); margin: 0 auto;">
          ${i}
        </button>
      `);
    }
    el.trxGrid.innerHTML = cells.join('');
    el.trxGrid.style.display = 'grid';
    el.trxGrid.style.gridTemplateColumns = 'repeat(5, 1fr)';
    el.trxGrid.style.gap = 'var(--sp-2)';

    el.trxGrid.addEventListener('click', e => {
      const cell = e.target.closest('[data-num]');
      if (!cell) return;
      const num = cell.dataset.num;
      const idx = state.selections.findIndex(s => s.value === num);
      if (idx >= 0) {
        state.selections.splice(idx, 1);
        cell.classList.remove('selected');
      } else {
        state.selections.push({ value: num, type: 'num' });
        cell.style.outline = '3px solid var(--brand)';
        cell.style.outlineOffset = '2px';
      }
      renderSlip();
    });
  }

  function renderSlip() {
    if (state.selections.length === 0) {
      el.slipBody.innerHTML = `<div class="bet-slip-empty">Pick a number</div>`;
      el.slipTotal.style.display = 'none';
      el.placeBet.style.display = 'none';
      return;
    }
    const amount = 1000 * state.multiplier;
    const total = state.selections.length * amount;

    el.slipBody.innerHTML = state.selections.map(s => `
      <div class="bet-slip-row">
        <div class="bet-slip-num">${s.value}</div>
        <input class="bet-slip-amt" type="number" value="${amount}" min="100" step="100" data-amount>
        <button class="bet-slip-remove" data-remove="${s.value}">✕</button>
      </div>
    `).join('');

    el.slipTotal.style.display = '';
    el.placeBet.style.display = '';
    el.totalAmount.textContent = `${total.toLocaleString('en-US')} K`;

    el.slipBody.querySelectorAll('[data-amount]').forEach(inp => {
      inp.addEventListener('input', () => {
        const v = Math.max(100, Number(inp.value) || 0);
        inp.value = v;
        const sum = [...el.slipBody.querySelectorAll('[data-amount]')].reduce((a, b) => a + Number(b.value), 0);
        el.totalAmount.textContent = `${sum.toLocaleString('en-US')} K`;
      });
    });
    el.slipBody.querySelectorAll('[data-remove]').forEach(btn => {
      btn.addEventListener('click', () => {
        const v = btn.dataset.remove;
        const idx = state.selections.findIndex(s => s.value === v);
        if (idx >= 0) state.selections.splice(idx, 1);
        const cell = el.trxGrid.querySelector(`[data-num="${v}"]`);
        if (cell) cell.style.outline = '';
        renderSlip();
      });
    });
  }

  el.placeBet?.addEventListener('click', () => {
    if (state.status === 'closed' || state.status === 'revealing') {
      window.ui.toast('Waiting for next period', 'info');
      return;
    }
    const amtInputs = [...el.slipBody.querySelectorAll('[data-amount]')];
    const bets = state.selections.map((s, i) => ({
      type: 'trx', value: s.value, amount: Number(amtInputs[i]?.value) || 1000,
      periodId: state.currentPeriod.periodId,
    }));
    const totalStake = bets.reduce((a, b) => a + b.amount, 0);

    state.user = state.user || window.store.getUser() || { balance: 0 };
    if (state.user.balance < totalStake) {
      window.ui.modal({ kind: 'lose', title: 'Insufficient balance', body: 'Not enough funds.', confirmText: 'OK' });
      return;
    }
    state.user.balance -= totalStake;
    window.store.setUser(state.user);
    refreshBalance();

    const stash = window.store.getBetslip();
    stash.selections = bets;
    stash.periodId = state.currentPeriod.periodId;
    stash.stake = totalStake;
    window.store.setBetslip(stash);

    window.ui.toast(`Bet placed: ${bets.length} pick(s), ${totalStake.toLocaleString()} K`, 'success');

    state.selections = [];
    el.trxGrid.querySelectorAll('[data-num]').forEach(c => c.style.outline = '');
    renderSlip();
  });

  el.clearSlip?.addEventListener('click', () => {
    state.selections = [];
    el.trxGrid.querySelectorAll('[data-num]').forEach(c => c.style.outline = '');
    renderSlip();
  });

  function startTicker() {
    window.drawEngine.startCountdown('wintrx', tick => {
      state.currentPeriod = tick.period;
      el.periodId.textContent = tick.period.periodId;
      el.cdMm.textContent = tick.mm;
      el.cdSs.textContent = tick.ss;
      el.status.className = `game-status ${tick.status}`;
      el.status.textContent = tick.status === 'open' ? 'Open' : tick.status === 'revealing' ? 'Revealing' : 'Closed';
      state.status = tick.status;

      if (tick.type === 'period-change') {
        settlePrevious(tick.period.seq - 1);
      }
    });
  }

  function settlePrevious(prevSeq) {
    const stash = window.store.getBetslip();
    if (!stash.periodId || !stash.selections?.length) return;

    const m = window.drawEngine.markets.wintrx;
    const periodStart = m.epochMs + (prevSeq - 1) * m.intervalMs;
    const d = new Date(periodStart);
    const yyyymmdd = `${d.getUTCFullYear()}${String(d.getUTCMonth()+1).padStart(2,'0')}${String(d.getUTCDate()).padStart(2,'0')}`;
    const prevId = m.periodFormat({ date: yyyymmdd, seq: prevSeq });

    if (stash.periodId !== prevId) return;

    // Generate result
    const seed = Array.from(prevId).reduce((a, c, i) => a + c.charCodeAt(0) * (i+1), 0);
    let s = seed;
    s = (s + 0x6D2B79F5) >>> 0;
    let t = s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    const r = ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    const num = Math.floor(r * 10);
    const chainHash = hex(int(r * (2**32)) & 0xFFFFFFFF)[2:].toUpperCase().slice(0, 6);

    let totalPayout = 0, wins = 0;
    stash.selections.forEach(bet => {
      if (String(bet.value) === String(num)) {
        wins++;
        totalPayout += bet.amount * 9; // 9x payout on TRX
      }
    });

    state.user = window.store.getUser() || { balance: 0 };
    state.user.balance += totalPayout;
    window.store.setUser(state.user);
    refreshBalance();

    if (wins > 0) {
      window.ui.modal({
        kind: 'win',
        title: 'You won!',
        body: `TRX result: <strong style="color:var(--trx-blue);font-size:36px;font-family:var(--font-num);">${num}</strong><br>Hash: <code>${chainHash}</code><br><br>${wins} winning pick(s) · <strong>${totalPayout.toLocaleString()} K</strong>`,
        confirmText: 'OK',
      });
      window.ui.beep('win');
    }
    window.store.clearBetslip();
  }

  function hex(n) { return n.toString(16); }
  function int(n) { return n & 0xFFFFFFFF; }

  async function loadHistory() {
    let draws = [];
    try { draws = await fetch('/data/draws-wintrx.json').then(r => r.json()); }
    catch (e) { return; }

    el.historyTable.innerHTML = draws.slice(-30).reverse().map(d => `
      <tr>
        <td class="mono">${d.periodId.slice(-12)}</td>
        <td><strong style="font-family: var(--font-num); font-size: var(--fs-lg);">${d.num}</strong></td>
        <td><code style="color: var(--trx-blue); font-size: var(--fs-xs);">${d.chainHash}</code></td>
      </tr>
    `).join('');

    const recent = draws.slice(-3).reverse();
    el.recent.innerHTML = recent.map(d => `
      <div class="recent-result">
        <div class="period">${d.periodId.slice(-8)}</div>
        <div class="result-tile" style="background: var(--accent-grad); border-color: var(--accent); width: 48px; height: 56px; font-size: var(--fs-2xl);">${d.num}</div>
        <div style="font-size: var(--fs-xs); color: var(--trx-blue); font-family: var(--font-num);">${d.chainHash}</div>
      </div>
    `).join('');

    // Display current TRX hash (mock)
    if (draws.length > 0) {
      const last = draws[draws.length - 1];
      el.trxHash.textContent = `${last.chainHash} · ${last.chainHash} · ${last.chainHash} · ${last.chainHash}`;
    }
  }

  function refreshBalance() {
    state.user = window.store.getUser() || { balance: 0 };
    if (el.balanceAmount) el.balanceAmount.textContent = state.user.balance.toLocaleString('en-US');
  }

  function initLang() {
    const btn = document.getElementById('langToggle');
    if (!btn) return;
    const refresh = () => { btn.textContent = window.i18n.getLang() === 'my' ? 'EN' : 'မြန်'; };
    refresh();
    btn.addEventListener('click', () => {
      window.i18n.setLang(window.i18n.getLang() === 'my' ? 'en' : 'my');
      refresh();
    });
  }

  document.addEventListener('DOMContentLoaded', () => {
    state.user = window.store.getUser() || { id: 'demo', name: 'Demo', balance: 100000, vipTier: 'gold' };
    window.store.setUser(state.user);

    window.i18n.applyTranslations();
    initLang();
    buildTrxGrid();
    document.querySelectorAll('[data-mult]').forEach(chip => {
      chip.addEventListener('click', () => {
        document.querySelectorAll('[data-mult]').forEach(c => c.classList.toggle('active', c === chip));
        state.multiplier = Number(chip.dataset.mult);
        renderSlip();
      });
    });
    refreshBalance();
    renderSlip();
    loadHistory();
    startTicker();
  });
})();