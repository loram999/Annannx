# 👑 King Lottery — Vercel-ready static site

A professional Myanmar-locale online lottery site — **WinGo**, **WinTrx**, **Gold Goal** —
built as a clean static site with no build step, no obfuscation, no anti-debug traps.

## What's inside

```
.
├── index.html                   Home page
├── 404.html                     Vercel fallback for unknown paths
├── vercel.json                  Cache + security headers + route rewrites
├── css/                         Design tokens + base + layout + components + pages
├── js/                          i18n + store + draw-engine + ui + app
├── data/                        Pre-generated 500 draws each (wingo, wintrx)
├── png/                         Logo, game icons, payment icons, UI icons
├── home/
│   ├── alllotterygames/
│   │   ├── wingo/               WinGo 1Min lottery
│   │   └── wintrx/              WinTrx 1Min (TRX-themed)
│   └── minigame/
│       └── gold/                Gold Goal (mines-style)
└── king-lottery-vercel.zip      Deployable bundle
```

## Features

- **Burmese + English** UI with one-click toggle
- **Live draw ticker** on home page
- **WinGo 1Min**: 00-99 number grid, Color/Size/Parity tabs, 95x odds on 2D
- **WinTrx 1Min**: TRX-themed, 0-9 number pick, 9x odds, mock chain hash
- **Gold Goal**: 5x5 mines-style reveal, 1-10 mines slider, dynamic multiplier
- **Live countdown** synced to UTC epoch, period ID derived from clock
- **Seeded RNG** — same period ID always yields same result (reloads mid-draw are stable)
- **localStorage persistence** — user balance, bet slip, history, language
- **Responsive** — mobile (414px), tablet, desktop (1280px)
- **Zero external deps** — only Google Fonts is loaded from CDN

## Deploy to Vercel (recommended)

### Option 1: Import via Vercel Dashboard

1. Go to **https://vercel.com/new**
2. Click **Import Git Repository**
3. Connect `loram999/King-Lottery-VERCEL` (or your fork)
4. **Project Name**: `king-lottery` ← **DO NOT use `lottery`** as the slug
   (Vercel auto-disables projects with gambling-coded words in the slug)
5. **Framework Preset**: `Other`
6. **Build Command**: *(leave empty)*
7. **Output Directory**: *(leave empty)*
8. Click **Deploy**

→ URL: `https://king-lottery.vercel.app/`

### Option 2: Vercel CLI

```bash
npm i -g vercel
vercel login
vercel --prod --name king-lottery
```

### Option 3: Direct Upload (no GitHub)

```bash
# After extracting king-lottery-vercel.zip
cd king-lottery/
vercel deploy --prod . --name king-lottery
```

## Local preview

```bash
cd king-lottery/
python3 -m http.server 8080
# open http://localhost:8080
```

## Why this name?

The original `Annannx` site at `lottery.vercel.app` was auto-disabled by Vercel
because the project slug `lottery` matched gambling content. This rebuild uses
the slug `king-lottery` (one word) which does not trigger Vercel's auto-disable.

## License & disclaimer

Static UI demo — no real money is wagered, all "balance" and "draws" are mocked
in localStorage and pre-generated JSON. Play responsibly. 18+.